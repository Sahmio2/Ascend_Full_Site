# Handoff contents

## Application source

- `app/` — pages, layouts, components and API routes
- `lib/` — authentication, persistence and programme helpers
- `db/` — Drizzle schema and database access
- `drizzle/` — six ordered database migrations plus metadata
- `public/` — current public assets
- `worker/` — Cloudflare Worker entry
- `build/` and `scripts/` — verified build and hosting support
- `tests/` — route/render regression tests
- Root configuration, lockfile and TypeScript/Tailwind/Vite settings

## Antigravity control material

- `00_ANTIGRAVITY_START_HERE.md`
- `01_LATEST_BUILD_PRECEDENCE.md`
- `02_ROUTE_AND_FEATURE_INVENTORY.md`
- `03_SETUP_AND_VALIDATION.md`
- `.agents/rules/` — Always On rules

## Reference material

The eight files in `reference-documents/` are supplied context. They are not replacements for the website source. See `reference-documents/README.md` for their role and conflict policy.

## Deliberately excluded

- `.git/`
- `node_modules/`
- `dist/`
- `.wrangler/`
- `.sites-runtime/`

These are generated, machine-specific or source-control internals and should not be copied between environments.

The source-controlled `.vinext/fonts/` assets are included; other `.vinext` build output is not.

Production D1 rows and R2-uploaded document bytes are hosted data rather than repository source, so they are not embedded in this ZIP. The schema, all migrations, bindings and upload/download code needed to keep using or provision those services are included.
