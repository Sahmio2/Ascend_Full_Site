# Latest-build precedence

## Priority order

Use this order whenever instructions or implementations conflict:

1. The extracted source files in this archive.
2. This precedence document and `00_ANTIGRAVITY_START_HERE.md`.
3. The Always On rules in `.agents/rules/`.
4. The newest ASCEND reference material in `reference-documents/` for brand and content context only.
5. Older GET DIVINE prompts, cached Antigravity code, previous ZIPs, screenshots and historical documents.

Source code is authoritative for current behaviour. Reference documents may explain brand, coaching content or desired information, but they must never be used to restore an older UI or delete newer application logic.

## Latest revision chain

| Priority | Revision | Date | Protected result |
| --- | --- | --- | --- |
| 1 | `96241ce` | 11 Aug 2026 | Compact underlined fields, meaningful paired inputs, content-sized controls and segmented short choices |
| 2 | `9ca0a98` | 11 Aug 2026 | Gold OGL specular treatment on the entrance and application CTAs |
| 3 | `e9a1058` | 11 Aug 2026 | Nine-stage premium assessment, reusable primitives, validation and progressive disclosure |
| 4 | `0bbe866` | 11 Aug 2026 | Compact single progress rail and mobile form density |
| 5 | `4baef0c` | 11 Aug 2026 | Responsive cinematic entrance |

The archive is based on revision `96241ce`. The later revision in each row already contains the required earlier work.

## Files with the newest protected work

- `app/apply/ApplicationForm.tsx`
- `app/apply/form-primitives.tsx`
- `app/apply/assessment-model.ts`
- `app/api/applications/route.ts`
- `app/components/SpecularButton.tsx`
- `app/components/SpecularButton.css`
- `app/components/AscendIcon.tsx`
- `app/globals.css`
- `app/page.tsx`
- `tests/rendered-html.test.mjs`
- `package.json`
- `package-lock.json`

Antigravity must inspect these files as they exist here before changing them. Never paste an older whole-file version over one of them.

## Resolved historical conflicts

| Older material may say | Current decision that wins |
| --- | --- |
| GET DIVINE as the visible primary identity | ASCEND is the visible primary identity; keep safe internal identifiers where already used |
| Paper/DOCX form layout | Responsive website UI with native semantic inputs and progressive disclosure |
| Adults only / 18+ entrance restriction | Current age validation and guardian-review payload logic in `assessment-model.ts` |
| Large bordered fields and cards | Compact underlined fields, restrained textareas and segmented choices |
| Several progress indicators or all section icons | One current-section icon, section name, percentage and thin meter |
| White specular line | Existing gold line treatment using ASCEND tokens |
| Vercel + React Router + LocalStorage-only architecture | Current Vinext/Worker/D1/R2 architecture in this archive |
| Rebuild from a generic dashboard template | Preserve the connected editorial website and app-like portal architecture |

