# Setup and validation

## Requirements

- Node.js 22.13 or newer
- npm
- Linux-compatible shell for the supplied verified build scripts

## Install

```bash
npm ci
```

Keep `package-lock.json`. Do not switch package managers or regenerate dependencies without a specific reason.

## Local development

```bash
npm run dev
```

The current Vite/Vinext configuration supplies local Worker bindings. Do not replace `vite.config.ts`, the `sites()` plugin or `worker/index.ts` with a generic Vite configuration.

## Quality gates

```bash
npm run lint
npm test
```

`npm test` performs the verified production build, artifact validation and rendered-route checks. The direct commands remain available:

```bash
npm run build
npm run validate:artifact
```

## Required regression checks after any change

- `/` renders the ASCEND identity and both `Apply for Coaching` CTAs still route correctly.
- `/apply` renders the cinematic entrance and `Begin Your Ascension Journey` starts the form.
- The single progress rail advances correctly across nine stages.
- Back/Continue preserves answers.
- Current-step validation shows inline messages and focuses the first invalid field.
- Contact, pain, allergy, Other and equipment follow-ups reveal only when relevant.
- Fitness goals remain multi-select.
- Applicants under 14 retain the existing guardian/coach review metadata.
- Sensitive answers are not written to safe LocalStorage drafts.
- Gold specular buttons retain normal, keyboard, reduced-motion and non-WebGL behaviour.
- Client, coach and demo routes remain separate.
- API payload keys and D1 migrations remain compatible.
- No horizontal overflow at 320, 375, 390, 430, 768, 1024 and 1440 pixels.
- Mobile text inputs remain at least 16px and practical touch targets remain approximately 44px.

## Environment and hosted bindings

The supplied hosting manifest declares `DB` for D1 and `BUCKET` for R2. Preserve these logical binding names. Apply migrations in numerical order from `drizzle/0000_...` through `drizzle/0005_...` when provisioning a fresh database.

Do not commit secrets or convert hosted bindings into hard-coded credentials.

