# Route and feature inventory

## Public routes

| Route | Current purpose |
| --- | --- |
| `/` | Editorial ASCEND marketing site and coaching CTA |
| `/apply` | Responsive cinematic entrance and nine-stage coaching intake |
| `/login` | Access entry for client and coach experiences |

## Client routes

| Route | Current purpose |
| --- | --- |
| `/client` | Client dashboard and overview |
| `/client/plan` | Assigned training plan |
| `/client/nutrition` | Nutrition hub and plan content |
| `/client/bmi` | Separate BMI calculator |
| `/client/workout-logger` | Programme-aware workout logging |
| `/client/progress` | Progress tracking |

## Coach route

| Route | Current purpose |
| --- | --- |
| `/coach` | Coach dashboard for people, applications, plans, check-ins, workouts and documents |

## Isolated demo routes

| Route | Current purpose |
| --- | --- |
| `/demo` | Demo access entry |
| `/demo/dashboard` | Demo client dashboard |
| `/demo/plan` | Demo plan |
| `/demo/nutrition` | Demo nutrition hub |
| `/demo/bmi` | Demo BMI calculator |
| `/demo/workout-logger` | Demo workout logger |
| `/demo/progress` | Demo progress tracking |

The demo must remain isolated from live client records.

## Server/API routes

- `POST /api/applications` — coaching application submission with idempotency handling.
- `/api/client` — authenticated client workspace data.
- `/api/client/workouts` — client workout reads and writes.
- `/api/client/documents/[id]` — client plan-document delivery.
- `/api/coach/people` and `/api/coach/people/[id]` — coach people/application management.
- `/api/coach/operations` — coach-side operational writes.
- `/api/coach/documents` — coach document upload and management.

## Persistence

The current schema in `db/schema.ts` and migrations in `drizzle/` cover:

- People/leads/clients
- Check-ins
- Activity timeline
- Idempotent application submissions
- Programme assignments
- Workout sessions and exercise logs
- Progress entries
- Subscriptions
- Plan documents

Do not rename database fields or assessment payload keys without a migration and compatibility plan.

## Authentication and access

- `app/chatgpt-auth.ts` contains the current ChatGPT/Sites identity helpers.
- `lib/client-auth.ts` resolves eligible client records and the existing demo-client mapping.
- `lib/coach-auth.ts` uses the configured coach allowlist.
- Development fallbacks exist for local preview only.

If a future host needs a different identity provider, adapt behind these boundaries. Do not spread a replacement authentication model across every page.

