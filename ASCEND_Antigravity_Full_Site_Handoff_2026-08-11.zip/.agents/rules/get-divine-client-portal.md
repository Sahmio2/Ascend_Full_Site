# Always On — client portal and demo

- Keep the client area app-like, mobile-first and visually connected to the public ASCEND identity.
- Preserve `/client`, `/client/plan`, `/client/nutrition`, `/client/bmi`, `/client/workout-logger` and `/client/progress`.
- Preserve the isolated matching `/demo/*` experience and never mix demo writes with live client records.
- Keep the current dashboard overview, plan, nutrition, BMI, workout logging and progress capabilities.
- The workout logger remains programme-aware and should preserve last-performance and exercise-log data structures.
- Keep the client and coach authentication boundaries in `lib/client-auth.ts` and `lib/coach-auth.ts`.
- Do not return the portal to a generic dashboard or move calculators/loggers into unrelated pages.
- Do not reintroduce RIR into client-facing programming unless explicitly requested.

