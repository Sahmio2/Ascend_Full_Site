# Always On — coach, data and QA

- Preserve `/coach` and the current coach operations, people, plan, workout, check-in and document workflows.
- Preserve D1/Drizzle as the durable record system and R2 as the plan-document storage boundary.
- Keep all existing schema fields and migrations. Never rename or delete data keys without a migration and backward-compatibility plan.
- Preserve application idempotency and the complete assessment payload.
- Keep contact, health and consent data out of safe LocalStorage drafts.
- Keep production authentication checks server-side and local fallbacks development-only.
- Verify public, client, coach and demo route separation after every change.
- Test responsive widths of 320, 375, 390, 430, 768, 1024 and 1440 pixels for affected UI.
- Run `npm run lint` and `npm test`; fix only errors caused by the change and report unrelated limitations separately.

