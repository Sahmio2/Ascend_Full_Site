# Always On — public site, assessment and access

- Keep the public website editorial, cinematic, responsive and restrained.
- Preserve `/`, `/apply` and `/login` and all existing CTA destinations.
- Keep the current gold specular treatment on `Begin Your Ascension Journey` and `Apply for Coaching`, including reduced-motion and non-WebGL fallbacks.
- Preserve the nine-step assessment, single compact progress rail, progressive disclosure and current data contract.
- Keep compact underlined fields, content-sized short inputs, short textareas and segmented choices. Do not restore large paper-style boxes.
- Do not show all section icons, multiple progress indicators, repeated form headings, ambiguous plus symbols, adult-only wording or RIR.
- Fitness goals remain multi-select. Native radio/checkbox semantics remain intact.
- Validate each step, focus the first invalid answer and preserve entries across Back/Continue.
- Keep safe-draft privacy exclusions and the existing under-14 guardian/coach review metadata.
- Hide the marketing footer during the active assessment flow if the current code does so.

