# Always On — ASCEND core

- Treat this archive as the newest and authoritative full-site baseline.
- Preserve the visible ASCEND identity, The Path to Divinity naming, black/ivory/gold palette and editorial typography.
- Preserve current routes, components, data keys, API contracts, schema, migrations and storage boundaries.
- Inspect before editing. Make targeted changes and do not replace the app with a generic template.
- The current code wins over older GET DIVINE instructions, historical stack notes, screenshots and DOCX layouts.
- Use the actual versions in `package.json` and `package-lock.json`; do not downgrade the stack.
- Keep semantic HTML, keyboard access, visible focus, reduced-motion support and responsive behaviour.
- Do not add paid dependencies or a new backend unless explicitly requested.
- After changes, run lint, tests and the production build and report exact changed files.

