# Reference documents

These files provide ASCEND brand, coaching, assessment, athlete-profile, nutrition, document-design and platform-structure context.

## Precedence rule

The website source and top-level latest-build instructions always win. Do not recreate a DOCX page inside the browser, restore paper-form boxes, replace native inputs with printable blanks, or overwrite current ASCEND copy and logic because a reference document differs.

Use the references for:

- Approved ASCEND language and coaching concepts
- Understanding the intended assessment information
- Client and athlete content context
- Nutrition/document-delivery context
- Editorial visual direction
- The connected public-website plus app-like portal model

Do not use them to:

- Downgrade the current application stack
- Restore the older GET DIVINE visible identity
- Remove current routes, database support or accessibility behaviour
- Replace the nine-step web assessment with a paper form
- Overwrite newer UI work in `app/apply`, `app/globals.css` or `app/components/SpecularButton*`

## Files

1. `01-Sahmi-Lyra.docx` — prompt-optimization context; lowest relevance to runtime code.
2. `02-ASCEND_Client_Self_Assessment_Form_v2_0_Gold_Border_Corrected.docx` — assessment content reference.
3. `03-ASCEND_Editable_Landing_Page_Template.docx` — ASCEND cover/identity reference.
4. `04-ASCEND_Path_to_Divinity_Master_Blueprint_v2_0.docx` — master brand and coaching-system blueprint.
5. `05-ASCEND_Sahmi_El_Athlete_Profile_v2_2_Gold_Border.docx` — athlete-profile reference.
6. `06-ASCEND_Personalized_Nutrition_Meal_and_Stock_Template_v2_0.docx` — nutrition-delivery reference.
7. `07-PREMIUM_DOCX_DESIGN_MASTER_GUIDE.docx` — document design only; not a website UI specification.
8. `08-structure-for-ASCEND.txt` — confirms editorial public website plus app-like client/coach portal direction.

