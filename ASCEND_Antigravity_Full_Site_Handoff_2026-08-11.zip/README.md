# ASCEND full-site Antigravity handoff

This archive is a complete source handoff for the current ASCEND website. It is not a partial `/apply` patch.

Start with [`00_ANTIGRAVITY_START_HERE.md`](00_ANTIGRAVITY_START_HERE.md). The archive source is the authoritative baseline and must replace older ASCEND or GET DIVINE source wherever the two conflict.

Snapshot date: **11 August 2026**  
Authoritative source revision: **`96241ce` — Refine assessment field density**  
Current production site: **https://get-divine-restored.ginikachukwu1m.chatgpt.site**

## Included

- Full public website
- Cinematic `/apply` entrance and nine-step coaching assessment
- Login and access routing
- Client portal and all client tools
- Coach portal and coach operations
- Complete demo experience
- Server routes, D1 schema and migrations
- R2-backed document support
- Current styles, icons, specular CTA component and assets
- Current tests and build configuration
- Antigravity Always On rules
- Supplied ASCEND reference documents

Generated folders and machine-specific caches are intentionally excluded: `.git`, `node_modules`, `dist`, `.wrangler`, and `.sites-runtime`. The tracked `.vinext/fonts` assets are included because they belong to the authoritative source snapshot.

## First commands

```bash
npm ci
npm run lint
npm test
npm run dev
```

Use Node.js **22.13 or newer**. Do not reinitialize this project from a generic template.
