# Antigravity execution brief — ASCEND full site

## Mission

Open this extracted folder as the project root and continue the existing ASCEND website from the supplied source. This is a full-site handoff: public pages, assessment, login, client portal, coach portal, demo, APIs, persistence and deployment configuration are all included.

## Non-negotiable source rule

The files in this archive are newer than any ASCEND or GET DIVINE build already held in the Antigravity workspace. When the same path, component, route, instruction or design decision exists in both places, **the archive version wins**.

Do not merge an older implementation back into these files. Do not reconstruct the site from screenshots, DOCX layouts, an old prompt, an old Vercel/Vite brief, cached code or a generic starter. Begin from this exact codebase.

## Required order of work

1. Read `01_LATEST_BUILD_PRECEDENCE.md`.
2. Load every file in `.agents/rules/` as an Always On project rule.
3. Inspect the existing source before editing.
4. Install from the existing lockfile with `npm ci`.
5. Run `npm run lint` and `npm test` before making changes.
6. Preserve every current route, data key, database migration, authentication adapter and submission contract.
7. Make only the newly requested change. Do not redesign unrelated areas.
8. Re-run lint, tests and the production build after changes.
9. Report changed files, data-model effects, test results and remaining limitations.

## Protected latest experience

Keep these current behaviours unless the user explicitly asks to change them:

- Visible brand: **ASCEND — The Path to Divinity** and **ASCEND BY SAHMI EL**.
- Public website remains editorial and cinematic; authenticated portals remain app-like.
- `/apply` begins with the responsive cinematic introduction and collapses into a focused form.
- The assessment has nine logical stages, one compact progress bar, progressive disclosure, inline validation, and safe draft persistence.
- Standard fields use the newest compact web-control treatment: underlined text inputs, short textareas, content-sized fields and segmented choices where appropriate.
- The form must not revert to large paper-style boxes, tiny `+` controls, repeated headings, a long single page, or one-question-per-screen Typeform behaviour.
- Fitness goals are multi-select.
- Applicants aged 13–100 can enter a valid age; an age below 14 is flagged for guardian/coach review through the existing payload logic. Do not add an unsupported legal claim.
- Sensitive contact and health answers remain excluded from LocalStorage drafts.
- `Begin Your Ascension Journey` uses the visible slow gold specular sweep; the two `Apply for Coaching` CTAs use the quieter pointer-proximity treatment.
- The OGL effect preserves reduced-motion, accessibility and non-WebGL fallbacks.
- Current black, ivory and gold tokens remain the visual source of truth.
- RIR remains absent from the public assessment and client-facing copy.

## Actual current stack

Trust `package.json` and the lockfile over older technical descriptions:

- React 19.2
- Next 16 application conventions compiled through Vinext
- Vite 8
- TypeScript 5.9
- Tailwind CSS 4.2 plus the custom token system in `app/globals.css`
- Cloudflare Worker runtime
- D1 with Drizzle migrations
- R2 document storage binding
- OGL for the specular CTA effect

Do not downgrade the project to React Router v7, Vite 6, TypeScript 5.7, Vercel-only deployment or LocalStorage-only application data because an older handoff mentions those technologies.

## Completion standard

A change is complete only when the site still builds, the relevant routes render, the responsive layout has no horizontal overflow, keyboard/focus/error states remain accessible, existing data is preserved, and the result starts from—not behind—the source in this archive.

