# Validation report

Validated on **11 August 2026** against the clean full-site source at revision `96241ce`.

## Results

| Check | Result |
| --- | --- |
| Source working tree | Clean before packaging |
| `npm run lint` | Passed |
| `npm test` | Passed |
| Verified production build | Passed |
| Deployable Worker artifact validation | Passed |
| Rendered `/` test | Passed |
| Rendered `/apply` entrance test | Passed |
| Current tracked source copied into handoff | 101 of 101 unchanged tracked files matched |
| Root README | Deliberately replaced with this project-specific handoff README; original runtime README preserved in `docs/SITES_RUNTIME_README.md` |

The build discovered the public, application, login, client, coach, demo and API routes listed in `02_ROUTE_AND_FEATURE_INVENTORY.md`.

## Informational warnings

- npm reported that its inherited `http-proxy` configuration will change in a future npm major version. This did not affect installation, linting, build or tests.
- Vinext reported that some routes could not be statically classified because dynamic headers/cookies can only be known at runtime. The build completed successfully.

## Packaging policy

Generated output and machine caches are not included. The package contains source, configuration, migrations, tracked fonts, tests, handoff instructions and the supplied reference documents.

