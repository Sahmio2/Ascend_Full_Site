# Always On — newest ASCEND build wins

For public design, `/apply`, compact fields, assessment logic and gold specular CTAs, the 11 August 2026 handoff is newer than prior Antigravity code and must replace conflicting older behaviour. Preserve target infrastructure, unrelated newer work and stored records while porting these newest features.
