# Always On — data and access safety

Preserve `gd_auth_session_v1` and `gd_app_data_v1`. Migrate forward without clearing data. Keep demo records isolated. Route every mutation through existing typed stores. Client/demo roles must never expose coach controls or real coach records. Keep coach login absent from public navigation.
