# Always On — change discipline and validation

Inspect existing equivalents before creating files. Merge instead of duplicating routers, stores, tokens or pages. Do not perform unrelated refactors. After changes, run the target typecheck, lint, tests and build; verify role boundaries, persistence, direct routes, application submission and responsive layouts before reporting completion.
