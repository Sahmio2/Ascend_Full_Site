# Always On — Antigravity stack

Keep the target on React 19, TypeScript 5.7, Vite 6, React Router v7, Tailwind CSS v4, the existing `src/App.tsx`, `authStore.ts`, `dataStore.ts`, LocalStorage keys and Vercel SPA deployment. Never replace it with the Next/Vinext/Worker/D1 runtime found in the hosted reference. Add only `ogl` when missing.
