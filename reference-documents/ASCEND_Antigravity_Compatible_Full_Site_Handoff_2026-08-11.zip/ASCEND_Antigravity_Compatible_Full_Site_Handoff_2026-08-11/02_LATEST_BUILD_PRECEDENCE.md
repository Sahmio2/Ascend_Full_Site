# Latest-build precedence

The target Antigravity project may contain older ASCEND pages. Apply precedence by responsibility, not by blindly replacing the repository.

## Interface and behaviour precedence

For the following areas, this handoff is newer and wins over older target implementations, screenshots, prompts and DOCX-derived layouts:

1. **Compact assessment fields** — source snapshot `96241ce`, 11 August 2026.
2. **Gold specular CTA effects** — source snapshot `9ca0a98`, 11 August 2026.
3. **Nine-stage accessible assessment rebuild** — source snapshot `e9a1058`, 11 August 2026.
4. Earlier compact entrance/progress refinements represented by `0bbe866`, `44a2a3a`, `4baef0c` and `eee6837`.

If the target has a larger paper-style form, ambiguous `+` controls, repeated headings, multiple progress systems, an 18+ statement, or older CTA styling, replace that older behaviour with the supplied newest version.

## Infrastructure and data precedence

The existing target repository wins for:

- package manager and lockfile;
- React/Vite/React Router/Tailwind runtime;
- route composition in `App.tsx`;
- `authStore.ts` and `dataStore.ts` implementations;
- LocalStorage migration and existing records;
- authentication credentials and route guards;
- Vercel configuration;
- unrelated features created after the target was last shared.

Adapt the newest interface into those systems. Do not preserve an old interface merely because the target architecture wins, and do not replace the architecture merely because the hosted implementation is newer.

## Protected newest behaviours

- `/apply` begins with the responsive cinematic entrance, then collapses into the focused form.
- The assessment has nine logical steps and one compact current-section bar with percentage and a thin meter.
- Standard text fields are quiet, underlined and content-sized; textareas start short; meaningful pairs stack on narrow phones.
- Input text remains at least 16px on phones; tap targets remain approximately 44px.
- Real radios and checkboxes replace tiny plus symbols.
- Fitness goals are multi-select.
- Contact, pain, allergies, equipment, movement notes and other follow-ups use progressive disclosure.
- Applicants aged 13–100 can enter a valid age. Applicants under 14 are marked for guardian/coach review without an invented legal claim.
- All existing assessment keys remain; `preferredContactMethod` is added.
- Sensitive contact, body, pain, health and consent answers remain excluded from safe LocalStorage drafts.
- `Begin Your Ascension Journey` uses a slow continuous gold sweep.
- Both `Apply for Coaching` calls to action use the quieter pointer-proximity gold effect.
- The effect has reduced-motion and non-WebGL fallbacks.
- ASCEND black `#090907`, ivory `#F3EDDF`, gold `#C7A45B` and bright gold `#DFBF77` remain authoritative.
- RIR stays absent from client-facing plans, logging and copy.

The eight reference documents support content decisions. They do not override this list.
