# ASCEND Antigravity-Compatible Full-Site Handoff

Start with `00_ANTIGRAVITY_START_HERE.md`.

This archive is designed to be merged into the user's existing Antigravity React/Vite repository. It is not a replacement runtime and must not be opened as a new standalone production project.

The archive contains:

- a React Router/Vite-compatible merge layer for the newest public site, nine-stage assessment, specular CTA treatment and client portal;
- a complete read-only snapshot of the latest hosted ASCEND site for behavioural and visual reference;
- strict technology, data, route and newest-build precedence rules;
- the eight current ASCEND reference documents;
- an isolated compatibility harness that proves the merge source compiles with React 19, TypeScript 5.7, Vite 6, React Router 7 and Tailwind CSS 4.

The target Antigravity repository remains authoritative for its package manager, lockfile, `src/App.tsx`, stores, persistence, authentication and Vercel configuration. The handoff is authoritative for the newer ASCEND interface and behaviour listed in `02_LATEST_BUILD_PRECEDENCE.md`.
