# Package contents

- `00_ANTIGRAVITY_START_HERE.md` — execution brief.
- `01_TECH_STACK_CONTRACT.md` — exact target architecture and forbidden migrations.
- `02_LATEST_BUILD_PRECEDENCE.md` — newest-build conflict rules.
- `03_MERGE_SEQUENCE.md` — implementation order.
- `04_SOURCE_PLACEMENT_MAP.md` — source-to-target translation.
- `05_ROUTE_AND_FEATURE_INVENTORY.md` — full-site acceptance scope.
- `06_VALIDATION_REPORT.md` — compatibility evidence and limitations.
- `ANTIGRAVITY_EXECUTION_PROMPT.md` — ready-to-paste implementation prompt.
- `HANDOFF_MANIFEST.json` — machine-readable stack and precedence contract.
- `.agents/rules/` — four Always On Antigravity rules.
- `antigravity-merge-source/` — Vite/React Router compatible latest public/application source, client/demo portal layer, CSS, fonts, dependency addition and Vercel rewrite template.
- `reference/latest-hosted-build-source/` — complete newest hosted website source, retained as read-only behaviour/reference material.
- `reference/project-documents/` — the eight current ASCEND source documents.
- `verification/` — isolated exact-line compatibility harness; not production source.
- `PACKAGE_FILE_LIST.txt` and `PACKAGE_SHA256SUMS.txt` — archive inventory and integrity data.

Excluded intentionally:

- Git metadata;
- `node_modules`;
- compiled `dist` and framework caches;
- hosted credentials and environment values;
- `.openai` hosting identity;
- deployed D1 records;
- uploaded R2 document bytes not present in source references.
