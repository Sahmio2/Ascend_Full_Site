# Required route and feature inventory

## Public

- `/` — cinematic ASCEND marketing page.
- `/apply` — cinematic entry plus nine-stage coaching assessment.
- `/login` — single visible client sign-in with demo access.

## Client

- `/client` redirects to or renders `/client/dashboard`.
- `/client/dashboard` — restrained streak/phase block, active programme, completed workouts, next check-in and nutrition summary.
- `/client/plan` — assigned programme days, sets, reps, rest, tempo and notes; no RIR.
- `/client/nutrition` — targets, macros, food logging, meal plan, hydration, supplements and guidelines.
- `/client/bmi` — metric/imperial BMI and calorie calculations.
- `/client/workout-logger` — programme day selection, automatic exercise population, previous loads and current set logging.
- `/client/progress` — check-ins, bodyweight/progress and coach feedback.

## Demo

Mirror the client route structure under `/demo/*`. Demo mutations must remain isolated from real LocalStorage application records.

## Coach

- `/coach` — separate coach sign-in, never linked publicly.
- `/coach-portal/*` — applications, athlete records, programmes, assignments, nutrition, check-ins, progress, documents, notes and feedback using existing store architecture.

## Access rules

- Client/demo sessions never render coach controls or real coach data.
- Public navigation exposes Client Login but not coach login.
- Direct refreshes on nested routes work through Vercel SPA rewrites.
- Unknown protected routes return to the correct role's dashboard.

## Current UI requirements

- No large paper-style form boxes.
- No tiny mobile text or horizontal overflow.
- No duplicated calorie-left display.
- No manual exercise-name entry in the workout logger.
- No RIR fields.
- Selected, focus, error and disabled states remain unambiguous and accessible.
