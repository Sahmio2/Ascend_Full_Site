# Execute this handoff inside the existing Antigravity project

You are a senior React/TypeScript engineer. Merge the newest ASCEND full-site implementation from this archive into the user's existing Antigravity repository.

Do not merely explain the migration. Inspect the target, implement it, validate it and report the changed files.

## Locate the target before editing

The target is the existing repository that contains all or most of:

- `package.json`
- `src/`
- `src/App.tsx`
- `vite.config.*`
- `tsconfig*.json`
- `vercel.json`
- one existing lockfile

If that repository is not available, stop and ask for it. Do not turn this handoff folder into a second production app.

## Required reading order

1. Load every file in `.agents/rules/` as an Always On rule.
2. Read `01_TECH_STACK_CONTRACT.md`.
3. Read `02_LATEST_BUILD_PRECEDENCE.md`.
4. Read `03_MERGE_SEQUENCE.md`.
5. Read `04_SOURCE_PLACEMENT_MAP.md`.
6. Read `05_ROUTE_AND_FEATURE_INVENTORY.md`.
7. Inspect the target project and run its existing baseline checks.

## How to use the supplied source

- `antigravity-merge-source/` contains browser-compatible React Router/Vite merge material. Merge its files into existing equivalents; do not create a second router or second store.
- `reference/latest-hosted-build-source/` is the complete newest hosted implementation. Read it to preserve behaviour, copy and visual details, but translate Next/Vinext/API concepts into the target architecture.
- `reference/project-documents/` provides supporting content and brand context only. It must never restore an older layout over the newer implementation.
- `verification/` is evidence and an isolated reproduction harness. Never copy its `package.json`, lockfile, `dist/` or dependencies into the target.

## Non-negotiable merge result

- Keep React 19, TypeScript 5.7, Vite 6, React Router v7, Tailwind CSS v4, `App.tsx`, `authStore.ts`, `dataStore.ts`, LocalStorage persistence and Vercel SPA hosting.
- Do not install Next.js, Vinext, Drizzle, Cloudflare Worker tooling or D1/R2 code.
- Merge only the missing `ogl` dependency for the specular CTA effect.
- Preserve `gd_auth_session_v1` and `gd_app_data_v1` and migrate stored data forward safely.
- Newer ASCEND form and CTA behaviour from this handoff replaces older versions already present in the target.
- Existing unrelated target features and user data must remain intact.
- Run the target's typecheck, lint, tests and production build, then inspect affected routes at mobile and desktop widths.
