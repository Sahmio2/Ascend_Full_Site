# Prompt to use with Antigravity

Use the attached `ASCEND_Antigravity_Compatible_Full_Site_Handoff_2026-08-11.zip` to update my existing Get Divine/ASCEND repository.

Work in my existing project—the repository with `src/App.tsx`, React 19, TypeScript 5.7, Vite 6, React Router v7, Tailwind CSS v4, `authStore.ts`, `dataStore.ts`, LocalStorage keys `gd_auth_session_v1` and `gd_app_data_v1`, and Vercel deployment. Do not create a second app and do not replace this stack with the hosted Next/Vinext reference.

Extract the ZIP beside the project, read `00_ANTIGRAVITY_START_HERE.md`, load all `.agents/rules/` files as Always On, and execute the merge. The 11 August 2026 compact assessment, nine-stage form and gold specular CTA builds are newer than older versions in my repository and must win where the UI or behaviour conflicts. My existing package manager, lockfile, stores, persistence, authentication, router and unrelated newer work must remain.

Use `antigravity-merge-source/` for compatible source and `reference/latest-hosted-build-source/` only to preserve complete current behaviour and visuals. Add `ogl` only if missing. Translate hosted API/database behaviour into my existing typed stores. Preserve all routes, data and access boundaries.

After implementation, run the repository's typecheck, lint, tests and production build. Test mobile and desktop layouts, form validation/submission, Back/Continue preservation, LocalStorage survival, demo isolation, client/coach guards, direct route refreshes and specular fallbacks. Fix implementation-caused failures and report every changed file, data migration, test result and remaining limitation.
