# Antigravity technology contract

This contract overrides conflicting technology descriptions inside older ASCEND handoffs or the hosted reference snapshot.

| Layer | Required target technology |
| --- | --- |
| UI | React `^19.0.0` and React DOM `^19.0.0` |
| Language | TypeScript `^5.7.0`, strict mode |
| Build | Vite `^6.1.0` with the target's existing React plugin |
| Routing | `react-router-dom` `^7.1.5`, configured through the existing `src/App.tsx` or router module |
| Styling | Tailwind CSS `^4.0.0` plus the target's existing `globals.css` design tokens |
| State | Existing typed in-memory/pub-sub stores |
| Persistence | LocalStorage through `authStore.ts` and `dataStore.ts` only |
| Session key | `gd_auth_session_v1` |
| Application-data key | `gd_app_data_v1` |
| Hosting | Vercel SPA with direct-route rewrite to `index.html` |

## Dependency rule

Inspect the target `package.json` and lockfile first. Keep all working target versions and the existing package manager. The only expected new runtime dependency is:

```json
{
  "ogl": "^1.0.11"
}
```

Do not copy a package file or lockfile from `reference/latest-hosted-build-source/` or `verification/`.

## Forbidden runtime changes

Do not add or migrate the target to:

- Next.js or Vinext;
- server components or `next/link`;
- Cloudflare Workers, Wrangler, D1, R2 or Drizzle;
- API route handlers from `app/api/**`;
- Redux, Zustand, Firebase, Supabase or a UI kit;
- a second `BrowserRouter`;
- a replacement store architecture.

## Translation rules

- `next/link` becomes React Router `Link` or `NavLink`.
- Next route folders become route elements in the existing router.
- hosted `/api/applications` submission becomes `dataStore.createApplication()` through the supplied adapter.
- hosted client/coach fetch calls become typed `dataStore` selectors and CRUD methods.
- D1/R2 schemas are references for fields only; they do not enter the target runtime.
- global styles must be merged into the target `globals.css`, preserving existing Tailwind initialization and tokens.
- authentication remains in `authStore.ts`; role guards remain client-side and role-aware.

The compatibility harness intentionally uses React 19.0.0, TypeScript 5.7.3, Vite 6.1.0, React Router 7.1.5 and Tailwind 4.0.17 to verify the supplied merge source on the approved major/minor lines.
