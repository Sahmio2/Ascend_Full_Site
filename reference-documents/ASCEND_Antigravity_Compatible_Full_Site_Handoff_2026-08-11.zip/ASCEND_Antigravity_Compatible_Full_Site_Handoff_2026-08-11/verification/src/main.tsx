import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { AscendPublicRoutes, registerAscendApplicationSubmitter } from "../../antigravity-merge-source/src/features/ascend/public-apply";
import GetDivinePortalRoutes from "../../antigravity-merge-source/src/features/ascend/portal/GetDivinePortalRoutes";
import "./verify.css";

registerAscendApplicationSubmitter(async () => ({
  reference: "verification-only",
}));

function VerificationApp() {
  return (
    <>
      <AscendPublicRoutes />
      <GetDivinePortalRoutes />
    </>
  );
}

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Missing #root mount element.");

createRoot(rootElement).render(
  <StrictMode>
    <BrowserRouter>
      <VerificationApp />
    </BrowserRouter>
  </StrictMode>,
);
