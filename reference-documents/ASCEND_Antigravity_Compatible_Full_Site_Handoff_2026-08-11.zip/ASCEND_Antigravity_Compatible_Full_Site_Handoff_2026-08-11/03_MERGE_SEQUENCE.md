# Safe full-site merge sequence

## 1. Inspect and protect the target

Before editing, inspect the target `package.json`, lockfile, `src/`, `App.tsx`, stores, types, global styles and `vercel.json`. Record the existing scripts. Create a recoverable Git checkpoint when Git is available. Do not reset or delete user work.

Run the existing typecheck, lint, tests and build. Record pre-existing failures separately from migration failures.

## 2. Merge public and application routes

Use `antigravity-merge-source/src/features/ascend/public-apply/` as the compatible source.

- Merge `HomePage.tsx` into the target's existing `/` page.
- Merge `ApplicationPage.tsx` and the `apply/` primitives/model into the existing `/apply` route.
- Use the supplied React Router imports; do not reintroduce `next/link`.
- Wire `connectAscendApplicationStore()` to the real `dataStore.createApplication()` once during app startup.
- Map the payload into the existing application record without renaming or dropping assessment keys.

## 3. Merge the client and demo portal

Use `antigravity-merge-source/src/features/ascend/portal/` as a compatibility layer, not a parallel application.

- Reuse existing pages/components when responsibilities match.
- Register the real store through the provided live bridge.
- Keep demo records isolated from `gd_app_data_v1`.
- Preserve programme-driven workout selection, previous-set recall, food logging, macros, calculators, check-ins and progress.
- Do not render RIR.

## 4. Reconcile login and coach routes

- Keep one visible public client login with the demo entry inside it.
- Keep `/coach` separate and absent from public navigation/footer.
- Preserve the target's coach authentication mechanism and coach records.
- Read `reference/latest-hosted-build-source/app/coach/CoachDashboard.tsx` and related API handlers for newest feature behaviour, then implement any missing behaviour through typed `dataStore` operations.
- Never copy the hosted authentication, D1, R2 or API runtime into the target.

## 5. Merge styling and the specular component

- Copy the supplied font files to the target `public/fonts/` only if equivalent files are not already present.
- Merge `ascend-fonts.css` definitions and the needed selectors from `ascend-latest-build.css` into the target global stylesheet.
- Preserve the target's single Tailwind import.
- Reuse existing token names where equivalent; do not create competing roots.
- Add `ogl` using the target's package manager and lockfile.
- Use the Vite-compatible `SpecularButton.tsx` and CSS.

## 6. Reconcile routes

Merge route elements into the existing router. Do not mount `AscendPublicRoutes` or `GetDivinePortalRoutes` inside a second `BrowserRouter`.

## 7. Migrate data forward

- Preserve `gd_auth_session_v1` and `gd_app_data_v1`.
- Add defaults for new fields during hydration.
- Never clear storage because a new field is missing.
- Keep application submission, drafts and demo data behind adapters.
- Do not persist sensitive medical/contact information through the safe-draft feature.

## 8. Validate

Run the target's typecheck, lint, tests and production build. Check direct-route refreshes, client/demo/coach access boundaries, form progress, validation, backward/forward preservation, draft safety, submission, specular fallbacks, LocalStorage survival and responsive layouts.

Report every changed file, data migration, check result and limitation.
