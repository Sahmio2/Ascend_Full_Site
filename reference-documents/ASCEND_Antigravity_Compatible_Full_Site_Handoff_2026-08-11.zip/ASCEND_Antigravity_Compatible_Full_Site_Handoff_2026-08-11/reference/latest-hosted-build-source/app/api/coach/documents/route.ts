import { getAuthorizedCoach } from "../../../../lib/coach-auth";
import { cleanText, ensureDatabase, getDatabase, getDocumentBucket } from "../../../../lib/database";
import { parseProgrammeDocx, ProgrammeImport } from "../../../../lib/programme-parser";

const allowedTypes = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

export async function GET() {
  const coach = await getAuthorizedCoach();
  if (!coach) return Response.json({ error: "Unauthorized" }, { status: 401 });
  await ensureDatabase();
  const db = await getDatabase();
  const documents = await db.prepare(`SELECT pd.id, pd.person_id, pd.title, pd.document_type, pd.file_name, pd.file_size, pd.status, pd.updated_at, p.full_name
    FROM plan_documents pd JOIN people p ON p.id = pd.person_id ORDER BY datetime(pd.updated_at) DESC LIMIT 100`).all();
  return Response.json({ documents: documents.results });
}

export async function POST(request: Request) {
  const coach = await getAuthorizedCoach();
  if (!coach) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const form = await request.formData();
  const file = form.get("file");
  const personId = cleanText(form.get("personId"), 80);
  const title = cleanText(form.get("title"), 120);
  const documentType = cleanText(form.get("documentType"), 30) || "training";
  if (!(file instanceof File) || !personId || !title) return Response.json({ error: "Athlete, title and file are required." }, { status: 400 });
  if (!allowedTypes.has(file.type) || file.size > 25 * 1024 * 1024) return Response.json({ error: "Upload a PDF or DOCX no larger than 25 MB." }, { status: 400 });
  const fileBytes = new Uint8Array(await file.arrayBuffer());
  let programmeImport: ProgrammeImport | null = null;
  if (documentType === "training" && file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
    try {
      programmeImport = parseProgrammeDocx(fileBytes);
    } catch (error) {
      return Response.json({ error: error instanceof Error ? error.message : "The training plan could not be read." }, { status: 422 });
    }
  }
  await ensureDatabase();
  const db = await getDatabase();
  const person = await db.prepare("SELECT id FROM people WHERE id = ? AND kind = 'client'").bind(personId).first();
  if (!person) return Response.json({ error: "Active athlete not found." }, { status: 404 });
  const id = crypto.randomUUID();
  const key = `client-plans/${personId}/${id}/${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  await (await getDocumentBucket()).put(key, fileBytes, { httpMetadata: { contentType: file.type } });
  const statements = [db.prepare(`INSERT INTO plan_documents
    (id, person_id, title, document_type, file_name, storage_key, content_type, file_size, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'published')`)
    .bind(id, personId, title, documentType, file.name, key, file.type, file.size)];
  let assignmentId = "";
  if (programmeImport?.workouts.length) {
    const existing = await db.prepare("SELECT id FROM program_assignments WHERE person_id = ? AND status IN ('active', 'draft') ORDER BY CASE status WHEN 'active' THEN 0 ELSE 1 END, datetime(updated_at) DESC LIMIT 1").bind(personId).first<{ id: string }>();
    const names = programmeImport.workouts.map((workout) => workout.name);
    const primary = programmeImport.workouts.filter((workout) => !workout.optional).map((workout) => workout.name);
    const optional = programmeImport.workouts.filter((workout) => workout.optional).map((workout) => workout.name);
    const now = new Date().toISOString();
    assignmentId = existing?.id || crypto.randomUUID();
    if (existing) {
      statements.push(db.prepare(`UPDATE program_assignments SET title = ?, days_per_week = ?, primary_workouts = ?, optional_workouts = ?, workout_plan = ?, updated_at = ? WHERE id = ? AND person_id = ?`)
        .bind(title, Math.max(1, Math.min(7, primary.length || names.length)), JSON.stringify(primary.length ? primary : names), JSON.stringify(optional), JSON.stringify(programmeImport.workouts), now, assignmentId, personId));
    } else {
      const profile = await db.prepare("SELECT phase FROM people WHERE id = ?").bind(personId).first<{ phase: string }>();
      statements.push(db.prepare(`INSERT INTO program_assignments
        (id, person_id, title, phase, days_per_week, status, athlete_instructions, primary_workouts, optional_workouts, workout_plan, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)`)
        .bind(assignmentId, personId, title, profile?.phase || "Taming the Flesh", Math.max(1, Math.min(7, primary.length || names.length)),
          "Select the scheduled programme day and record each completed working set.", JSON.stringify(primary.length ? primary : names), JSON.stringify(optional), JSON.stringify(programmeImport.workouts), now, now));
    }
    statements.push(db.prepare("INSERT INTO activities (id, person_id, type, summary, created_at) VALUES (?, ?, 'programme_imported', ?, ?)")
      .bind(crypto.randomUUID(), personId, `${title} loaded ${programmeImport.exerciseCount} exercises across ${programmeImport.workouts.length} workout days.`, now));
  }
  await db.batch(statements);
  const document = await db.prepare("SELECT * FROM plan_documents WHERE id = ?").bind(id).first();
  const assignment = assignmentId ? await db.prepare("SELECT * FROM program_assignments WHERE id = ?").bind(assignmentId).first() : null;
  return Response.json({ document, assignment, programmeImport, autoLoadSupported: documentType !== "training" || file.type.includes("wordprocessingml") }, { status: 201 });
}
