import { cleanText, ensureDatabase, getDatabase, parseList } from "../../../lib/database";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function validIdempotencyKey(value: string) {
  return /^[a-f0-9-]{20,80}$/i.test(value);
}

export async function POST(request: Request) {
  try {
    const raw = await request.text();
    if (raw.length > 180_000) return Response.json({ error: "The assessment is too large to submit." }, { status: 413 });
    const body = JSON.parse(raw) as Record<string, unknown>;
    const fullName = cleanText(body.fullName, 120);
    const email = cleanText(body.email, 160).toLowerCase();
    const whatsapp = cleanText(body.whatsapp, 60);
    const website = cleanText(body.website, 100);
    const age = Number(cleanText(body.age, 10));
    const selectedGoals = parseList(body.selectedGoals);
    const primaryGoal = cleanText(body.primaryGoal, 120);
    const idempotencyKey = cleanText(body.idempotencyKey, 100);
    const assessment = isRecord(body.assessment) ? body.assessment : null;
    const consent = assessment && isRecord(assessment.consent) ? assessment.consent : null;

    if (website) return Response.json({ ok: true }, { status: 201 });
    if (!fullName || (!email && !whatsapp)) {
      return Response.json({ error: "Name and at least one contact method are required." }, { status: 400 });
    }
    if (email && !/^\S+@\S+\.\S+$/.test(email)) {
      return Response.json({ error: "Enter a valid email address." }, { status: 400 });
    }
    if (!Number.isInteger(age) || age < 13 || age > 100) {
      return Response.json({ error: "Enter a valid age between 13 and 100." }, { status: 400 });
    }
    if (!selectedGoals.length || !primaryGoal) {
      return Response.json({ error: "Choose at least one fitness goal and a main coaching priority." }, { status: 400 });
    }
    if (selectedGoals.length > 1 && !selectedGoals.includes(primaryGoal) && !selectedGoals.includes("Other")) {
      return Response.json({ error: "The main priority must match one of the selected goals." }, { status: 400 });
    }
    if (!consent || consent.accuracy !== true || consent.scope !== true || consent.symptomNotice !== true || consent.trackingCommitment !== true) {
      return Response.json({ error: "All final confirmations are required." }, { status: 400 });
    }
    if (!validIdempotencyKey(idempotencyKey)) {
      return Response.json({ error: "Start a new submission and try again." }, { status: 400 });
    }

    await ensureDatabase();
    const db = await getDatabase();
    const existing = await db.prepare("SELECT reference FROM application_submissions WHERE idempotency_key = ?").bind(idempotencyKey).first<{ reference: string }>();
    if (existing?.reference) return Response.json({ ok: true, reference: existing.reference }, { status: 201 });

    const id = crypto.randomUUID();
    const reference = `AS-${id.slice(0, 8).toUpperCase()}`;
    const now = new Date().toISOString();
    const daysAvailable = parseList(body.daysAvailable);
    const equipment = parseList(body.equipment);
    const trackingReadiness = parseList(body.trackingReadiness);
    const urgencyRaw = Number(body.goalUrgency);
    const goalUrgency = Number.isFinite(urgencyRaw) ? Math.max(1, Math.min(10, Math.round(urgencyRaw))) : 5;
    const applicationData = JSON.stringify({ ...body, website: undefined });

    try {
      await db.batch([
        db.prepare("INSERT INTO application_submissions (idempotency_key, person_id, reference, created_at) VALUES (?, ?, ?, ?)").bind(idempotencyKey, id, reference, now),
        db.prepare(`INSERT INTO people (
          id, kind, status, full_name, email, whatsapp, city_country, age, height, bodyweight,
          primary_goal, goal_detail, goal_urgency, training_age,
          preferred_frequency, session_length, access_type, days_available,
          equipment, pain_context, consistency_barrier, tracking_readiness,
          application_data, created_at, updated_at
        ) VALUES (?, 'lead', 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).bind(
          id, fullName, email, whatsapp, cleanText(body.cityCountry, 160), String(age), cleanText(body.height, 40), cleanText(body.bodyweight, 40),
          primaryGoal, cleanText(body.goalDetail, 1200), goalUrgency, cleanText(body.trainingAge, 80), cleanText(body.preferredFrequency, 60), cleanText(body.sessionLength, 60), cleanText(body.accessType, 160),
          JSON.stringify(daysAvailable), JSON.stringify(equipment), cleanText(body.painContext, 1200), cleanText(body.consistencyBarrier, 800), JSON.stringify(trackingReadiness), applicationData, now, now,
        ),
        db.prepare("INSERT INTO activities (id, person_id, type, summary, created_at) VALUES (?, ?, 'application', ?, ?)").bind(crypto.randomUUID(), id, `${fullName} submitted a coaching application.`, now),
      ]);
    } catch {
      const duplicate = await db.prepare("SELECT reference FROM application_submissions WHERE idempotency_key = ?").bind(idempotencyKey).first<{ reference: string }>();
      if (duplicate?.reference) return Response.json({ ok: true, reference: duplicate.reference }, { status: 201 });
      throw new Error("application-write-failed");
    }

    return Response.json({ ok: true, reference }, { status: 201 });
  } catch {
    return Response.json({ error: "We could not send your assessment. Please try again." }, { status: 500 });
  }
}
