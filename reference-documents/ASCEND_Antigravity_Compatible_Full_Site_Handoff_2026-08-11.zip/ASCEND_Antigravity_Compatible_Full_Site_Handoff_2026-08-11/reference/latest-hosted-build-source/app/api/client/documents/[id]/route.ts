import { getAuthorizedClient } from "../../../../../lib/client-auth";
import { ensureDatabase, getDatabase, getDocumentBucket } from "../../../../../lib/database";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const client = await getAuthorizedClient();
  if (!client) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await context.params;
  await ensureDatabase();
  const db = await getDatabase();
  const document = await db.prepare(
    "SELECT file_name, storage_key, content_type FROM plan_documents WHERE id = ? AND person_id = ? AND status = 'published'"
  ).bind(id, client.personId).first<{ file_name: string; storage_key: string; content_type: string }>();
  if (!document) return Response.json({ error: "Document not found." }, { status: 404 });
  const object = await (await getDocumentBucket()).get(document.storage_key);
  if (!object) return Response.json({ error: "File is unavailable." }, { status: 404 });
  const safeName = document.file_name.replace(/["\r\n]/g, "");
  return new Response(object.body, {
    headers: {
      "content-type": document.content_type,
      "content-disposition": `attachment; filename="${safeName}"`,
      "cache-control": "private, no-store",
    },
  });
}
