import { getAuthorizedClient } from "../../../lib/client-auth";
import { ensureDatabase, getDatabase } from "../../../lib/database";

const sampleWorkoutPlan = [
  { id: "upper-a", name: "Upper A — Press & Pull", focus: "Build controlled strength through horizontal pressing and rowing.", optional: false, exercises: [
    { id: "upper-a-incline-press", name: "Incline Dumbbell Press", type: "Main lift", prescribedSets: 3, setPrescription: "3", reps: "8–10", rest: "120 sec", tempo: "3-1-1", notes: "Keep the shoulder blades set and stop one clean rep before form changes." },
    { id: "upper-a-row", name: "Chest-Supported Row", type: "Main lift", prescribedSets: 3, setPrescription: "3", reps: "8–12", rest: "120 sec", tempo: "2-1-1", notes: "Drive the elbows back without lifting the chest from the pad." },
    { id: "upper-a-raise", name: "Cable Lateral Raise", type: "Isolation", prescribedSets: 3, setPrescription: "3", reps: "12–15", rest: "60 sec", tempo: "2-1-2", notes: "Lead with the elbow and keep the upper trap quiet." },
    { id: "upper-a-pulldown", name: "Neutral-Grip Lat Pulldown", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "10–12", rest: "90 sec", tempo: "2-1-2", notes: "Pull to the upper chest without leaning back." },
  ] },
  { id: "lower-a", name: "Lower A — Squat Emphasis", focus: "Build leg strength with stable positions and repeatable depth.", optional: false, exercises: [
    { id: "lower-a-squat", name: "High-Bar Back Squat", type: "Main lift", prescribedSets: 4, setPrescription: "4", reps: "6–8", rest: "180 sec", tempo: "3-1-1", notes: "Use the same stance and depth on every working rep." },
    { id: "lower-a-rdl", name: "Romanian Deadlift", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "8–10", rest: "120 sec", tempo: "3-1-1", notes: "Keep the bar close and stop before the pelvis tucks." },
    { id: "lower-a-leg-curl", name: "Seated Leg Curl", type: "Isolation", prescribedSets: 3, setPrescription: "3", reps: "10–15", rest: "75 sec", tempo: "2-1-2", notes: "Hold the shortened position for one count." },
    { id: "lower-a-calf", name: "Standing Calf Raise", type: "Isolation", prescribedSets: 3, setPrescription: "3", reps: "10–15", rest: "60 sec", tempo: "2-1-2", notes: "Pause in the stretch and at the top." },
  ] },
  { id: "upper-b", name: "Upper B — Back & Delts", focus: "Accumulate quality upper-back and shoulder work without losing control.", optional: false, exercises: [
    { id: "upper-b-pulldown", name: "Assisted Pull-Up", type: "Main lift", prescribedSets: 3, setPrescription: "3", reps: "6–10", rest: "120 sec", tempo: "2-1-2", notes: "Use the least assistance that preserves full range." },
    { id: "upper-b-press", name: "Machine Shoulder Press", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "8–12", rest: "90 sec", tempo: "2-1-2", notes: "Keep the ribcage stacked and use a pain-free range." },
    { id: "upper-b-row", name: "Single-Arm Cable Row", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "10–12", rest: "75 sec", tempo: "2-1-2", notes: "Finish with the elbow, not torso rotation." },
    { id: "upper-b-rear-delt", name: "Reverse Pec Deck", type: "Isolation", prescribedSets: 3, setPrescription: "3", reps: "12–15", rest: "60 sec", tempo: "2-1-2", notes: "Keep the shoulders down as the arms open." },
  ] },
  { id: "lower-b", name: "Lower B — Hinge & Glutes", focus: "Train the posterior chain with deliberate loading and stable joints.", optional: false, exercises: [
    { id: "lower-b-hip-thrust", name: "Barbell Hip Thrust", type: "Main lift", prescribedSets: 4, setPrescription: "4", reps: "8–10", rest: "150 sec", tempo: "2-1-2", notes: "Finish with the glutes without overextending the lower back." },
    { id: "lower-b-leg-press", name: "Leg Press", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "10–12", rest: "120 sec", tempo: "3-1-1", notes: "Use the deepest stable range that keeps the pelvis planted." },
    { id: "lower-b-split-squat", name: "Rear-Foot Elevated Split Squat", type: "Secondary", prescribedSets: 3, setPrescription: "3", reps: "8–10 / side", rest: "90 sec", tempo: "3-1-1", notes: "Keep the front foot planted and the descent controlled." },
    { id: "lower-b-leg-curl", name: "Lying Leg Curl", type: "Isolation", prescribedSets: 3, setPrescription: "3", reps: "10–15", rest: "75 sec", tempo: "2-1-2", notes: "Keep the hips heavy on the pad." },
  ] },
];

const sample = {
  person: { full_name: "Amara O.", phase: "Forging the Form", primary_goal: "Body recomposition", next_check_in: "2026-08-10" },
  assignments: [{ id: "sample-assignment", title: "Ascension Block 01", phase: "Forging the Form", days_per_week: 4, status: "active", starts_on: "2026-07-20", ends_on: "2026-08-16", athlete_instructions: "Move with control, record every working set, and stop any movement that creates sharp pain.", primary_workouts: JSON.stringify(sampleWorkoutPlan.map((workout) => workout.name)), optional_workouts: "[]", workout_plan: JSON.stringify(sampleWorkoutPlan) }],
  workouts: [
    { id: "demo-workout-1", workout_date: "2026-08-04", workout_name: "Upper A — Press & Pull", completion_status: "completed", duration_minutes: 68, effort_rating: 8, athlete_note: "Strong session.", coach_feedback: "Excellent control. Add 2 kg to the press when all sets reach 10.", exercise_log: JSON.stringify([
      { name: "Incline Dumbbell Press", sets: [{ set: 1, reps: "10", load: "24 kg" }, { set: 2, reps: "9", load: "24 kg" }, { set: 3, reps: "8", load: "24 kg" }] },
      { name: "Chest-Supported Row", sets: [{ set: 1, reps: "12", load: "45 kg" }, { set: 2, reps: "11", load: "45 kg" }, { set: 3, reps: "10", load: "45 kg" }] },
      { name: "Cable Lateral Raise", sets: [{ set: 1, reps: "15", load: "5 kg" }, { set: 2, reps: "14", load: "5 kg" }, { set: 3, reps: "13", load: "5 kg" }] },
      { name: "Neutral-Grip Lat Pulldown", sets: [{ set: 1, reps: "12", load: "48 kg" }, { set: 2, reps: "11", load: "48 kg" }, { set: 3, reps: "10", load: "48 kg" }] },
    ]) },
    { id: "demo-workout-2", workout_date: "2026-08-01", workout_name: "Lower A — Squat Emphasis", completion_status: "completed", duration_minutes: 74, effort_rating: 8, athlete_note: "Depth stayed consistent.", coach_feedback: "Repeat the squat load and add one rep to set three.", exercise_log: JSON.stringify([
      { name: "High-Bar Back Squat", sets: [{ set: 1, reps: "8", load: "70 kg" }, { set: 2, reps: "8", load: "70 kg" }, { set: 3, reps: "7", load: "70 kg" }, { set: 4, reps: "6", load: "70 kg" }] },
      { name: "Romanian Deadlift", sets: [{ set: 1, reps: "10", load: "62.5 kg" }, { set: 2, reps: "9", load: "62.5 kg" }, { set: 3, reps: "8", load: "62.5 kg" }] },
    ]) },
  ],
  documents: [
    { id: "demo-training", title: "Ascension Training Plan", document_type: "training", file_name: "ASCEND_Training_Plan.pdf", file_size: 1840000, updated_at: "2026-07-25T10:00:00Z", demo: true },
    { id: "demo-nutrition", title: "Personalised Nutrition & Meal Guide", document_type: "nutrition", file_name: "ASCEND_Nutrition_Plan.pdf", file_size: 1320000, updated_at: "2026-07-25T10:00:00Z", demo: true },
  ],
};

export async function GET(request: Request) {
  if (new URL(request.url).searchParams.get("demo") === "1") return Response.json(sample);
  const client = await getAuthorizedClient();
  if (!client) return Response.json({ error: "Unauthorized" }, { status: 401 });
  if (client.personId === "sample-client") return Response.json(sample);
  await ensureDatabase();
  const db = await getDatabase();
  const [person, assignments, workouts, documents] = await Promise.all([
    db.prepare("SELECT id, full_name, phase, primary_goal, next_check_in FROM people WHERE id = ?").bind(client.personId).first(),
    db.prepare("SELECT id, title, phase, days_per_week, status, starts_on, ends_on, athlete_instructions, primary_workouts, optional_workouts, workout_plan FROM program_assignments WHERE person_id = ? ORDER BY datetime(updated_at) DESC").bind(client.personId).all(),
    db.prepare("SELECT id, workout_date, workout_name, completion_status, duration_minutes, effort_rating, athlete_note, coach_feedback, exercise_log FROM workout_sessions WHERE person_id = ? ORDER BY date(workout_date) DESC, datetime(created_at) DESC LIMIT 50").bind(client.personId).all(),
    db.prepare("SELECT id, title, document_type, file_name, file_size, updated_at FROM plan_documents WHERE person_id = ? AND status = 'published' ORDER BY datetime(updated_at) DESC").bind(client.personId).all(),
  ]);
  return Response.json({ person, assignments: assignments.results, workouts: workouts.results, documents: documents.results });
}
