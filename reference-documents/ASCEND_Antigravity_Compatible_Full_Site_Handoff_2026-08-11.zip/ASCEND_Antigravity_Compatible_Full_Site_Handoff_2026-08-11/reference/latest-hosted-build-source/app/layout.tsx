import type { Metadata } from "next";
import { Cinzel, Cormorant_Garamond, DM_Sans } from "next/font/google";
import "./globals.css";

const display = Cormorant_Garamond({
  variable: "--font-display",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
});

const sans = DM_Sans({
  variable: "--font-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const ceremonial = Cinzel({
  variable: "--font-ceremonial",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

export const metadata: Metadata = {
  applicationName: "ASCEND",
  title: {
    default: "ASCEND — The Path to Divinity",
    template: "%s | ASCEND",
  },
  description:
    "A structured guide to an aesthetic, powerful physique. Tame the flesh. Forge the form. Ascend.",
  creator: "Sahmi El",
  openGraph: {
    type: "website",
    siteName: "ASCEND",
    title: "ASCEND — The Path to Divinity",
    description: "A structured guide to an aesthetic, powerful physique.",
  },
  twitter: {
    card: "summary",
    title: "ASCEND — The Path to Divinity",
    description: "A structured guide to an aesthetic, powerful physique.",
  },
  manifest: "/manifest.webmanifest",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body
        className={`${display.variable} ${sans.variable} ${ceremonial.variable}`}
      >
        {children}
      </body>
    </html>
  );
}
