import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { chatGPTSignInPath, chatGPTSignOutPath, getChatGPTUser } from "../../chatgpt-auth";
import { getAuthorizedClient } from "../../../lib/client-auth";
import WorkoutLogger from "../WorkoutLogger";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Workout Logger", description: "Record your ASCEND training sessions." };

export default async function ClientWorkoutLoggerPage() {
  const signedIn = process.env.NODE_ENV === "development" ? null : await getChatGPTUser();
  if (process.env.NODE_ENV !== "development" && !signedIn) redirect(chatGPTSignInPath("/client/workout-logger"));
  const client = await getAuthorizedClient();
  if (!client) return <main className="client-access-state"><Link className="wordmark" href="/"><span>ASCEND</span></Link><p className="eyebrow">Client access</p><h1>Your account is signed in.</h1><p>This email is not connected to an active ASCEND client record yet.</p><div><Link className="button button-outline" href="/">Return home</Link><a className="button button-gold" href={chatGPTSignOutPath("/client/workout-logger")}>Use another account</a></div></main>;
  return <WorkoutLogger clientName={client.displayName} signOutPath={chatGPTSignOutPath("/")} />;
}
