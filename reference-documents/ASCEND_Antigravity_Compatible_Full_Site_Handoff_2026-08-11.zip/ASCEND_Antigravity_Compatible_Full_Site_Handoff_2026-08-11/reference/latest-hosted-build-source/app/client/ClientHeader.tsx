import Link from "next/link";

export default function ClientHeader({ clientName, signOutPath, demo, current }: { clientName: string; signOutPath: string; demo?: boolean; current: "dashboard" | "bmi" | "logger" }) {
  const basePath = demo ? "/demo" : "/client";
  const dashboardPath = demo ? "/demo/dashboard" : "/client";
  return (
    <header className="client-nav">
      <Link className="wordmark" href="/"><span>ASCEND</span></Link>
      <nav aria-label="Client workspace">
        <Link className={current === "dashboard" ? "active" : ""} href={dashboardPath}>Dashboard</Link>
        <Link className={current === "bmi" ? "active" : ""} href={`${basePath}/bmi`}>BMI calculator</Link>
        <Link className={current === "logger" ? "active" : ""} href={`${basePath}/workout-logger`}>Workout logger</Link>
      </nav>
      <div>{demo && <b className="demo-badge">Demo mode</b>}<span>{clientName}</span><a href={signOutPath}>{demo ? "Exit demo" : "Sign out"}</a></div>
    </header>
  );
}
