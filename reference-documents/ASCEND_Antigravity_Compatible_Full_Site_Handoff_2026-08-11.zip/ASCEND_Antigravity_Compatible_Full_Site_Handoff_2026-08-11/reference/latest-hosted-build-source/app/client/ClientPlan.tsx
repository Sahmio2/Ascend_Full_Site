"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import PortalShell from "./PortalShell";
import { ClientData, dateLabel, parseWorkoutPlan } from "./client-types";

export default function ClientPlan({ clientName, signOutPath, demo = false }: { clientName: string; signOutPath: string; demo?: boolean }) {
  const [data, setData] = useState<ClientData | null>(null);
  const [notice, setNotice] = useState("");
  const activeProgramme = data?.assignments.find((item) => item.status === "active") ?? data?.assignments[0];
  const workoutPlan = useMemo(() => parseWorkoutPlan(activeProgramme?.workout_plan), [activeProgramme?.workout_plan]);
  const basePath = demo ? "/demo" : "/client";

  useEffect(() => {
    fetch(demo ? "/api/client?demo=1" : "/api/client")
      .then((response) => {
        if (!response.ok) throw new Error("We could not load your plan.");
        return response.json();
      })
      .then(setData)
      .catch((error) => setNotice(error.message));
  }, [demo]);

  return (
    <PortalShell clientName={clientName} signOutPath={signOutPath} demo={demo} current="plan" phase={data?.person.phase}>
      {notice && <div className="portal-notice"><span>Update</span><p>{notice}</p><button onClick={() => setNotice("")} aria-label="Dismiss update">×</button></div>}
      <section className="portal-page-heading">
        <div><p className="portal-kicker">ASCEND plan</p><h1>Your week, already decided.</h1><p>Follow the programme your coach assigned—sets, reps, tempo and execution notes are all here.</p></div>
        <Link className="portal-page-action" href={`${basePath}/workout-logger`}>Start a workout <span>→</span></Link>
      </section>

      <section className="portal-overview portal-page-overview">
        <article><span>Active programme</span><strong>{activeProgramme?.title || "Preparing your plan"}</strong><small>{activeProgramme ? `${dateLabel(activeProgramme.starts_on)} — ${dateLabel(activeProgramme.ends_on)}` : "Your coach will publish this"}</small></article>
        <article><span>Weekly frequency</span><strong>{activeProgramme?.days_per_week || workoutPlan.length || "—"} days</strong><small>Primary sessions</small></article>
        <article><span>Current phase</span><strong>{activeProgramme?.phase || data?.person.phase || "Ascension"}</strong><small>Coach assigned</small></article>
      </section>

      <section className="portal-plan-layout">
        <div className="portal-plan-days">
          <div className="portal-section-heading"><div><p className="portal-kicker">Workout routines</p><h2>Programme days</h2></div><span>{workoutPlan.length} days</span></div>
          {workoutPlan.map((workout, workoutIndex) => (
            <article className="portal-plan-day" key={workout.id}>
              <header><div><span>Day {String(workoutIndex + 1).padStart(2, "0")}</span><h3>{workout.name}</h3><p>{workout.focus}</p></div><strong>{workout.exercises.length} exercises</strong></header>
              <div className="portal-plan-exercises">
                {workout.exercises.map((exercise, exerciseIndex) => (
                  <div key={exercise.id}><span>{String(exerciseIndex + 1).padStart(2, "0")}</span><p><strong>{exercise.name}</strong><small>{exercise.setPrescription || exercise.prescribedSets} sets · {exercise.reps} reps · {exercise.rest}</small>{exercise.notes && <em>{exercise.notes}</em>}</p><b>{exercise.tempo || "Controlled"}</b></div>
                ))}
              </div>
            </article>
          ))}
          {!workoutPlan.length && <div className="portal-empty-state"><span>Plan in preparation</span><h3>Your workout days will appear here.</h3><p>Your coach’s uploaded programme automatically builds this weekly view.</p></div>}
        </div>

        <aside className="portal-plan-aside">
          <article className="portal-panel"><p className="portal-kicker">Coach direction</p><h2>How to use this block.</h2><p>{activeProgramme?.athlete_instructions || "Move with control, record every working set, and stop any movement that creates sharp pain."}</p></article>
          <article className="portal-panel"><p className="portal-kicker">Plan documents</p><div className="portal-document-list">{data?.documents.map((document) => <div key={document.id}><span>{document.document_type === "nutrition" ? "N" : "T"}</span><p><strong>{document.title}</strong><small>{document.file_name}</small></p>{document.demo ? <b>Demo</b> : <a href={`/api/client/documents/${document.id}`}>↓</a>}</div>)}{!data?.documents.length && <p className="portal-empty-copy">Published documents will appear here.</p>}</div></article>
        </aside>
      </section>
    </PortalShell>
  );
}
