import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { chatGPTSignInPath, chatGPTSignOutPath, getChatGPTUser } from "../../chatgpt-auth";
import { getAuthorizedClient } from "../../../lib/client-auth";
import ClientPlan from "../ClientPlan";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "My Plan", description: "Your ASCEND training programme." };

export default async function ClientPlanPage() {
  const signedIn = process.env.NODE_ENV === "development" ? null : await getChatGPTUser();
  if (process.env.NODE_ENV !== "development" && !signedIn) redirect(chatGPTSignInPath("/client/plan"));
  const client = await getAuthorizedClient();
  if (!client) return <main className="client-access-state"><Link className="wordmark" href="/"><span>ASCEND</span></Link><p className="eyebrow">Client access</p><h1>Your account is signed in.</h1><p>This email is not connected to an active ASCEND client record yet.</p><div><Link className="button button-outline" href="/">Return home</Link><a className="button button-gold" href={chatGPTSignOutPath("/client/plan")}>Use another account</a></div></main>;
  return <ClientPlan clientName={client.displayName} signOutPath={chatGPTSignOutPath("/")} />;
}
