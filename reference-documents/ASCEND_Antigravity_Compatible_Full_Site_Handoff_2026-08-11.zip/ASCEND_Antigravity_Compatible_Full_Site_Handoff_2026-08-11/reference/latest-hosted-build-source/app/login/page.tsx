import type { Metadata } from "next";
import DemoLogin from "../demo/DemoLogin";

export const metadata: Metadata = {
  title: "Client Login",
  description: "Access your private ASCEND client experience or enter the demo workspace.",
};

export default function LoginPage() {
  return <DemoLogin />;
}
