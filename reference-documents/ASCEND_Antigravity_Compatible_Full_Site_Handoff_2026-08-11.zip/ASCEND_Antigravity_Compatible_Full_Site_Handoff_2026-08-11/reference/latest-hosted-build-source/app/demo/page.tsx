import type { Metadata } from "next";
import DemoLogin from "./DemoLogin";

export const metadata: Metadata = { title: "Demo Login", description: "Access or inspect the ASCEND client experience." };

export default function DemoPage() {
  return <DemoLogin />;
}
