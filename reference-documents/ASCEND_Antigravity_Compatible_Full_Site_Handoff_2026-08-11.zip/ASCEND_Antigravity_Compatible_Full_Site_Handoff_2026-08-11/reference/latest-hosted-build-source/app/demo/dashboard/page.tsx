import type { Metadata } from "next";
import ClientWorkspace from "../../client/ClientWorkspace";

export const metadata: Metadata = { title: "Demo Client Dashboard", description: "Inspect the ASCEND client dashboard." };

export default function DemoDashboardPage() {
  return <ClientWorkspace clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />;
}
