"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";

export default function DemoLogin() {
  const [loading, setLoading] = useState(false);
  function enter(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    window.setTimeout(() => window.location.assign("/demo/dashboard"), 450);
  }
  return (
    <main className="demo-login">
      <Link className="wordmark" href="/"><span>ASCEND</span></Link>
      <section className="demo-login-card unified-login-card">
        <div className="demo-login-copy">
          <p className="eyebrow">ASCEND by Sahmi El</p>
          <h1>Client Access</h1>
          <p>Sign in to continue your ASCEND coaching experience. The demo remains available for anyone reviewing the complete client workspace.</p>
          <a className="button button-ivory client-signin-button" href="/client">Client sign in →</a>
          <small className="client-signin-note">Use the ChatGPT email connected to your ASCEND client record.</small>
          <ul><li>BMI & energy calculators</li><li>Training and nutrition documents</li><li>Programme-loaded workout logging</li><li>Previous weights and coach feedback</li></ul>
        </div>
        <form onSubmit={enter}>
          <span className="demo-lock">◆</span>
          <h2>Demo client login</h2>
          <p>Use these demo credentials to inspect every client feature.</p>
          <label><span>Email</span><input value="demo@ascend.co" readOnly /></label>
          <label><span>Password</span><input value="ascend-demo" type="password" readOnly /></label>
          <button className="button button-gold" type="submit" disabled={loading}>{loading ? "Opening workspace…" : "Login to demo →"}</button>
          <small>Demo actions are temporary and do not affect real client records.</small>
          <div className="applicant-route">
            <p>Not currently an ASCEND client?</p>
            <Link href="/apply">Apply for Coaching →</Link>
          </div>
        </form>
      </section>
    </main>
  );
}
