import type { Metadata } from "next";
import ClientPlan from "../../client/ClientPlan";

export const metadata: Metadata = { title: "Demo ASCEND Plan", description: "Inspect the ASCEND client programme." };
export default function DemoPlanPage() { return <ClientPlan clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />; }
