import type { Metadata } from "next";
import WorkoutLogger from "../../client/WorkoutLogger";

export const metadata: Metadata = { title: "Demo Workout Logger", description: "Inspect the ASCEND workout logging experience." };

export default function DemoWorkoutLoggerPage() {
  return <WorkoutLogger clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />;
}
