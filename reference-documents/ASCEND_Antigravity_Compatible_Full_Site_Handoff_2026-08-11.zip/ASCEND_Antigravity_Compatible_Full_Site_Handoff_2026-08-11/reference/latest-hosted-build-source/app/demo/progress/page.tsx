import type { Metadata } from "next";
import ProgressHub from "../../client/ProgressHub";

export const metadata: Metadata = { title: "Demo Progress", description: "Inspect the ASCEND client progress experience." };
export default function DemoProgressPage() { return <ProgressHub clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />; }
