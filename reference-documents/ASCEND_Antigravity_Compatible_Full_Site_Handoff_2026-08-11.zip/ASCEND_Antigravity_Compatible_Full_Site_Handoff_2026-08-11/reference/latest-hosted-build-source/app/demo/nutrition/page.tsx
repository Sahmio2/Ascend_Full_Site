import type { Metadata } from "next";
import NutritionHub from "../../client/NutritionHub";

export const metadata: Metadata = { title: "Demo Nutrition", description: "Inspect the ASCEND client nutrition experience." };
export default function DemoNutritionPage() { return <NutritionHub clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />; }
