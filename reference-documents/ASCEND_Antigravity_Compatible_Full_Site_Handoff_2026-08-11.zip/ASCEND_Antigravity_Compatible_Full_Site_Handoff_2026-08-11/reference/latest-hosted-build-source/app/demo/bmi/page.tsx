import type { Metadata } from "next";
import BmiCalculator from "../../client/BmiCalculator";

export const metadata: Metadata = { title: "Demo BMI Calculator", description: "Inspect the ASCEND BMI and calorie calculator." };

export default function DemoBmiPage() {
  return <BmiCalculator clientName="Amara O. — Demo Athlete" signOutPath="/login" demo />;
}
