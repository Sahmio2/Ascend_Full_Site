import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "ASCEND — The Path to Divinity",
    short_name: "ASCEND",
    description: "A structured guide to an aesthetic, powerful physique.",
    start_url: "/",
    display: "standalone",
    background_color: "#090907",
    theme_color: "#090907",
    icons: [
      {
        src: "/favicon.svg",
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
