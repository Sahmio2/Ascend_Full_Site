import assert from "node:assert/strict";
import test from "node:test";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

async function loadWorker() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  return (await import(workerUrl.href)).default;
}

async function renderPath(worker, path) {
  const response = await worker.fetch(
    new Request(`http://localhost${path}`, {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  return response;
}

test("renders development preview metadata", async () => {
  const worker = await loadWorker();
  const response = await renderPath(worker, "/");

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  const html = await response.text();
  assert.match(html, developmentPreviewMeta);
  assert.match(html, /specular-button/);
  assert.match(html, /Apply for Coaching/i);
});

test("renders the cinematic coaching-assessment entrance", async () => {
  const worker = await loadWorker();
  const response = await renderPath(worker, "/apply");
  const html = await response.text();

  assert.equal(response.status, 200);
  assert.match(html, /Before the ascent/i);
  assert.match(html, /Begin Your/i);
  assert.match(html, /Ascension Journey/i);
  assert.match(html, /application-entrance-cta/);
  assert.match(html, /specular-button/);
  assert.match(html, /Coaching, not diagnosis/i);
  assert.doesNotMatch(html, /Step 1 of 10/i);
  assert.doesNotMatch(html, /18 or over/i);
  assert.doesNotMatch(html, /adult online assessment/i);
  assert.doesNotMatch(html, /Emergency contact/i);
  assert.doesNotMatch(html, /\bRIR\b/i);
});
