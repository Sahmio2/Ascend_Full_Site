CREATE TABLE `plan_documents` (
  `id` text PRIMARY KEY NOT NULL,
  `person_id` text NOT NULL,
  `title` text NOT NULL,
  `document_type` text DEFAULT 'training' NOT NULL,
  `file_name` text NOT NULL,
  `storage_key` text NOT NULL,
  `content_type` text NOT NULL,
  `file_size` integer DEFAULT 0 NOT NULL,
  `status` text DEFAULT 'published' NOT NULL,
  `created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
  `updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `plan_documents_person_idx` ON `plan_documents` (`person_id`);
