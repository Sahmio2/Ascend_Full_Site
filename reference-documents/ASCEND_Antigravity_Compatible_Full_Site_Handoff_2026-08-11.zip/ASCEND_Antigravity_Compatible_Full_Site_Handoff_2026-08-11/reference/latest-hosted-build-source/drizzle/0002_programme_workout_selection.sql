ALTER TABLE `program_assignments` ADD `primary_workouts` text NOT NULL DEFAULT '[]';
--> statement-breakpoint
ALTER TABLE `program_assignments` ADD `optional_workouts` text NOT NULL DEFAULT '[]';
