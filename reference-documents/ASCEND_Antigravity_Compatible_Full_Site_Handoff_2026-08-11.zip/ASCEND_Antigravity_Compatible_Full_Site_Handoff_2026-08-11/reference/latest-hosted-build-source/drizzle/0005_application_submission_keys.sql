CREATE TABLE IF NOT EXISTS `application_submissions` (
  `idempotency_key` text PRIMARY KEY NOT NULL,
  `person_id` text NOT NULL,
  `reference` text NOT NULL,
  `created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `application_submissions_person_idx` ON `application_submissions` (`person_id`);
