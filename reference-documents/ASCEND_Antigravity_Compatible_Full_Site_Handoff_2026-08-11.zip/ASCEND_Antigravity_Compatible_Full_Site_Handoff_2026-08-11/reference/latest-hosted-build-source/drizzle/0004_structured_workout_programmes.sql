ALTER TABLE `program_assignments` ADD `workout_plan` text NOT NULL DEFAULT '[]';
