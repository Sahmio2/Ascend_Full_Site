# Source placement map

Use existing target paths when equivalents already exist. The destinations below are preferred only when the target has no established equivalent.

| Supplied source | Preferred target responsibility | Required adaptation |
| --- | --- | --- |
| `public-apply/pages/HomePage.tsx` | existing public home page | Merge newest content and specular CTAs; retain React Router links. |
| `public-apply/pages/ApplicationPage.tsx` | existing `/apply` page | Keep the current header and responsive introduction. |
| `public-apply/apply/ApplicationForm.tsx` | application feature/page component | Keep all fields and logic; submit through the adapter. |
| `public-apply/apply/assessment-model.ts` | application domain model | Preserve every key, payload transform, validation and safe-draft filtering. |
| `public-apply/apply/form-primitives.tsx` | shared application controls | Merge semantic fieldsets, labels, radio/checkbox cards, errors, progress and actions. |
| `public-apply/data/applicationAdapter.ts` | application/store integration boundary | Register the existing `dataStore.createApplication()` method. |
| `public-apply/components/SpecularButton.tsx` | shared CTA component | Keep OGL, reduced-motion fallback and React Router link implementation. |
| `public-apply/components/AscendIcon.tsx` | shared icon component | Reuse if the target has no equivalent thin-line icon family. |
| `portal/GetDivinePortalRoutes.tsx` | existing `App.tsx` route tree | Merge its elements into the existing router; do not add a second router. |
| `portal/pages/*` | existing client/demo pages | Merge newest portal content into existing pages and store selectors. |
| `portal/data/clientPortalAdapter.ts` | store adapter | Connect to `dataStore`; keep demo state isolated. |
| `portal/data/demoSeed.ts` | deterministic demo data | Keep outside real client records. |
| `portal/data/liveBridge.template.ts` | integration example | Adapt to actual target method names; do not copy blindly. |
| `src/styles/ascend-fonts.css` | target `globals.css` or font stylesheet | Merge once and copy only missing fonts. |
| `src/styles/ascend-latest-build.css` | target `globals.css` | Merge selectors/tokens; do not replace unrelated rules. |
| `PACKAGE_ADDITIONS.json` | target `package.json` | Add only missing `ogl`; never copy the file wholesale. |
| `VERCEL_REWRITE_TEMPLATE.json` | target `vercel.json` | Use only if the target lacks an equivalent SPA rewrite. |

## Hosted reference map

`reference/latest-hosted-build-source/` contains the complete latest implementation. Use it as follows:

| Hosted area | Antigravity translation |
| --- | --- |
| `app/page.tsx` | public React Router page |
| `app/apply/**` | supplied Vite-compatible application feature |
| `app/login/**`, `app/demo/**` | one client login plus isolated demo routes |
| `app/client/**` | client pages backed by `dataStore` |
| `app/coach/**` | coach portal backed by existing coach store methods |
| `app/api/**` | behaviour to express as store operations; never copy server handlers |
| `db/**`, `drizzle/**` | field/reference information only |
| `lib/programme-parser.ts` | browser-safe programme parser under target `src/lib/` |
| `app/globals.css` | merge only needed tokens and selectors |

Do not copy the hosted root package, lockfile, Next/Vinext configuration, build scripts, Worker code, database runtime or hosting metadata into the target.
