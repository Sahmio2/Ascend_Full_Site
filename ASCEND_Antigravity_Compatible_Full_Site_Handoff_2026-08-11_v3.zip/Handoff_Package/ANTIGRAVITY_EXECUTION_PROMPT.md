# Ready-to-Paste Antigravity Execution Prompt

Use the attached `Handoff_Package` and treat `source-reference-read-only/project-sources/09-ASCEND_Website_Migration_Handoff_Standard_v1_0_2026-08-11.md` as binding.

First inspect my existing repository: package versions, lockfile, `App.tsx`, `main.tsx`, global styles, `authStore.ts`, `dataStore.ts`, storage keys, demo state, Vercel configuration, repository instructions, routes, and dirty changes. Record the current target commit and produce a route/feature/data conflict matrix before editing.

Then merge the complete browser-ready source from `antigravity-merge-source/` into my existing React 19 + TypeScript 5.7 + Vite 6 + React Router 7 + Tailwind CSS 4 application. Do not create a second app and do not copy `source-reference-read-only/latest-hosted-build/` into runtime code.

Newer UI and behaviour in this handoff win over older implementations. Preserve my target architecture, `App.tsx`, `authStore.ts`, `dataStore.ts`, `gd_auth_session_v1`, `gd_app_data_v1`, lockfile, Tailwind setup, existing routes and Vercel deployment. Add only missing dependencies from `PACKAGE_ADDITIONS.json`.

Connect the supplied async application, safe-draft, client, demo-auth and coach bridges to my existing stores. Do not add a database yet. Do not store real sensitive applications in LocalStorage. Keep the repository seam ready for a secure database/API later.

Complete every route and feature in `03_ROUTE_INTEGRATION_MAP.md`; do not leave placeholders. Run the full gate in `05_VALIDATION_AND_QA.md`. Report the source/target commits, every changed file, dependencies, route/store/schema changes, tests, responsive widths, intentional differences, and unresolved backend/privacy work.
