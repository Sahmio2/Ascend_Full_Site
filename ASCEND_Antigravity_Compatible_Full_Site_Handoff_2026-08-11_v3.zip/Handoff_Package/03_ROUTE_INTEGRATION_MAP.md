# Route Integration Map

Register these elements in the target’s existing React Router v7 tree. Do not add another `BrowserRouter` and do not replace `App.tsx`.

| URL | Supplied element | Behaviour |
|---|---|---|
| `/` | `HomePage` | ASCEND editorial homepage |
| `/apply` | `ApplicationPage` | complete nine-stage coaching intake |
| `/login` | `DemoLoginPage` or target login shell | unified visible entry; role handling remains separate |
| `/demo` | redirect | `/demo/dashboard` |
| `/demo/dashboard` | `DashboardPage scope="demo"` | populated isolated demo |
| `/demo/plan` | `PlanPage scope="demo"` | demo plan |
| `/demo/nutrition` | `NutritionPage scope="demo"` | targets, meals and food logging |
| `/demo/bmi` | `CalculatorPage scope="demo"` | BMI/calculator experience |
| `/demo/calculators/bmi` | alias | redirect to `/demo/bmi` |
| `/demo/calculators/calories` | alias | preserve target alias or map to calculator suite |
| `/demo/workout-logger` | `WorkoutLoggerPage scope="demo"` | programme-day logger and previous sets |
| `/demo/progress` | `ProgressPage scope="demo"` | check-ins and progress |
| `/client` | redirect | `/client/dashboard` |
| `/client/dashboard` | `DashboardPage scope="live"` | target-store-backed client overview |
| `/client/plan` | `PlanPage scope="live"` | live programme |
| `/client/nutrition` | `NutritionPage scope="live"` | live nutrition and food log |
| `/client/bmi` | `CalculatorPage scope="live"` | live calculator |
| `/client/calculators/bmi` | alias | redirect to `/client/bmi` |
| `/client/calculators/calories` | alias | preserve target alias or map to calculator suite |
| `/client/workout-logger` | `WorkoutLoggerPage scope="live"` | live workout logger |
| `/client/progress` | `ProgressPage scope="live"` | live check-ins/progress |
| `/coach` | alias | redirect to `/coach-portal` |
| `/coach-portal` | `CoachPortalPage` | coach operations workspace |

`AscendFullSiteRoutes.tsx` is an integration example. Where the target already owns a URL, use its guard/layout and mount the supplied page component inside it.

## Auth expectations

- Client and coach roles remain distinct even when there is one visible login page.
- Demo routes use fictional seed data and must not expose or mutate live records.
- The target `authStore.ts` remains the authority for protected routes, session expiry, sign-out, and role checks.
