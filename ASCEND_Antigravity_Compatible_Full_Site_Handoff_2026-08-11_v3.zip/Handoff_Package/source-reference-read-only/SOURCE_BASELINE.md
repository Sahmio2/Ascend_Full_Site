# Source Baseline

- Site: ASCEND — The Path to Divinity
- Source commit: `96241cea4aa2a6ab06e7fb9cd954d760164b4075`
- Commit date: 11 August 2026
- Latest hosted version observed while packaging: 20
- Worktree state: clean
- Most recent source changes, newest first:
  1. Refine assessment field density
  2. Add ASCEND specular CTA effects
  3. Redesign ASCEND coaching assessment

The hosted source controls current visual/behavioural parity. It does not control the target runtime architecture.
