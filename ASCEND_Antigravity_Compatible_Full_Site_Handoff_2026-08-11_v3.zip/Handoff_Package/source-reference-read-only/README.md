# Read-Only Sources

Nothing in this directory is a direct runtime merge target.

- `latest-hosted-build/` documents the exact Next/Vinext/Cloudflare source baseline.
- `project-sources/` contains migration, brand, form, programme, nutrition and document references.

When a supporting document conflicts with the latest working UI, apply the precedence in `../06_SOURCE_PRECEDENCE_AND_CONFLICTS.md`.
