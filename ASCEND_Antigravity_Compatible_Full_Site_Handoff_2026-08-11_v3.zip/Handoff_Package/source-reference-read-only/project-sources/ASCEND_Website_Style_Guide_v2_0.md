---
title: "ASCEND — Website Style Guide"
subtitle: "The Path to Divinity"
version: "2.0"
status: "Implementation-ready current system"
owner: "ASCEND by Sahmi El"
last_updated: "2026-08-10"
supersedes: "Get Divine Website Style Guide v1.0"
---

# ASCEND Website Style Guide

> *The Path to Divinity*  
> **Tame the flesh. Forge the form. Ascend.**  
> A structured guide to an aesthetic, powerful physique.  
> **by Sahmi El**

This guide defines the approved brand, interface, content, accessibility, and implementation standards for the ASCEND website and its public, client, demo, intake, and coach experiences.

It updates the former Get Divine system without redesigning its black, ivory, and gold visual identity. It is written for designers, developers, copywriters, content editors, and AI agents working on the website.

---

## 1. Decision Status

Every rule belongs to one of four levels.

| Status | Meaning |
|---|---|
| **Approved** | Directly established by the current ASCEND rebrand and coaching system. |
| **Implemented** | Present in the current website and required for visual or functional parity. |
| **Compatibility** | May remain internally during migration but must not appear as current-facing brand copy. |
| **To confirm** | Requires an explicit product, legal, or content decision before release. |

### Approved foundations

- Primary brand: **ASCEND**
- Brand subtitle: **The Path to Divinity**
- Method: **Tame the flesh. Forge the form. Ascend.**
- Descriptor: **A structured guide to an aesthetic, powerful physique.**
- Founder line: **by Sahmi El**
- Formal creator treatment: **ASCEND BY SAHMI EL**
- Narrative sequence: **Tame → Forge → Ascend**
- Signature standard: **Train with intention. Progress with structure.**
- Phase system: **Phase I — Taming the Flesh; Phase II — Forging the Form; Phase III — Ascension**
- Visual world: **near-black, charcoal, ivory, paper, restrained gold**
- Type roles: **Cormorant Garamond + DM Sans + Cinzel**
- Icon language: **the approved 18-icon thin-line SVG family**
- Voice: **direct, premium, mythic in restraint, practical, respectful, and safety-aware**

### Implemented product decisions

- The full client self-assessment is a nine-stage intake experience.
- On desktop, the form card is the left column and the description panel is the right column.
- On mobile, the form appears first and the description follows beneath it.
- **Coaching Intake Assessment** is the single title inside the form card.
- Public and form body copy is at least 16px on phones.
- The client dashboard combines streak/consistency and training phase in one responsive summary block.
- The nutrition interface presents one calorie gauge with the macro breakdown beside it.
- Client-facing RIR is removed. Exercise prescriptions use sets, reps, rest, load history, and execution notes.
- The demo experience is fully seeded and isolated from live client data.

---

## 2. Rebrand and Naming System

### 2.1 Canonical brand presentation

| Element | Approved expression |
|---|---|
| Primary brand | **ASCEND** |
| Subtitle | **The Path to Divinity** |
| Method | **Tame the flesh. Forge the form. Ascend.** |
| Descriptor | **A structured guide to an aesthetic, powerful physique.** |
| Founder line | **by Sahmi El** |
| Formal creator line | **ASCEND BY SAHMI EL** |
| Narrative sequence | **Tame → Forge → Ascend** |
| Signature | **Train with intention. Progress with structure.** |

### 2.2 Legacy replacement map

| Retired current-facing copy | Approved replacement |
|---|---|
| `GET DIVINE` | `ASCEND` |
| `Get Divine` | `ASCEND` |
| `GET DIVINE WITH SAHMI EL` | `ASCEND BY SAHMI EL` |
| `Get Divine with Sahmi El` | `ASCEND by Sahmi El` |
| `The Ascension Program` | `The Path to Divinity` |
| `A structured path to an aesthetic, powerful physique.` | `A structured guide to an aesthetic, powerful physique.` |

### 2.3 Protected language

Do not globally replace the word **Ascension**. Keep these expressions unchanged:

- **Phase I — Taming the Flesh**
- **Phase II — Forging the Form**
- **Phase III — Ascension**
- **Tame the flesh. Forge the form. Ascend.**
- **Tame → Forge → Ascend**
- A programme or training block may retain an approved operational name such as **Ascension Block 01**.

### 2.4 Naming rules

- Use **ASCEND** in the wordmark, hero, navigation, footer, app name, metadata, and formal brand contexts.
- Use **ASCEND by Sahmi El** when a mixed-case creator line is appropriate.
- Use **ASCEND BY SAHMI EL** for compact ceremonial labels.
- Use **The Path to Divinity** as the brand subtitle, not as a replacement for Phase III — Ascension.
- Keep the word **Ascension** only where it describes the approved phase system, an intentionally named programme block, or historical/archive content.
- Do not expose retired brand wording in UI copy, page titles, image alt text, schema, manifests, emails, or seeded data.
- Existing URLs do not change automatically during the rebrand.

---

## 3. Brand Idea

ASCEND is a premium physique coaching system built around mastery, form, and intentional progression rather than chaos, punishment, or random intensity.

### Tame the flesh

Establish command over inconsistency, impulse, poor technique, ego lifting, and disordered habits. The body is not the enemy. Disorder is.

### Forge the form

Turn disciplined action into visible structure through organised training, nutrition, recovery, strength, muscular shape, proportion, symmetry, and performance.

### Ascend

Refine what has been built. Remove wasted effort, specialise intelligently, improve precision, and create a system that can survive changing goals and seasons of life.

### Brand operating sentence

> Brand creates belief. Phase creates direction. Level creates dosage. Profile creates fit. Digital delivery creates usability.

---

## 4. Digital Experience Principles

### 4.1 Monumental, not loud

Create authority through typography, contrast, composition, and space rather than noise.

### 4.2 Editorial, not generic SaaS

Avoid soft rounded-card overload, bright dashboard colours, oversized icon libraries, decorative gradients, and patterns that make the site feel interchangeable.

### 4.3 Mythic at key moments, practical at the point of action

The hero, phase introductions, and manifesto moments may be ceremonial. Forms, plans, nutrition targets, coaching instructions, and calls to action must be plain and immediate.

### 4.4 Client-first

The visitor or client should understand:

1. What ASCEND is.
2. What transformation it offers.
3. How the method works.
4. Whether coaching is relevant to them.
5. What action to take next.
6. Where to find their current programme, targets, and next check-in.

### 4.5 Low density with purpose

Do not fill negative space merely because space exists. Every decorative or informational element must support hierarchy, trust, or action.

### 4.6 Premium means trust

Luxury language never replaces clarity, evidence, safety, privacy, responsive behaviour, or respectful client care.

### 4.7 Parity before reinterpretation

When porting the website between frameworks or hosts, preserve the established JSX structure, CSS hierarchy, typography, icon paths, responsive order, interactions, and seeded demo state before adapting the data layer.

---

## 5. Brand Architecture

| Layer | Purpose | Approved expression |
|---|---|---|
| Brand | Public identity | ASCEND |
| Subtitle | Meaning and positioning | The Path to Divinity |
| Method | Behavioural transformation | Tame the flesh. Forge the form. Ascend. |
| Phase | Current direction | Taming the Flesh / Forging the Form / Ascension |
| Level | Training dosage | Beginner / Intermediate / Advanced |
| Profile | Individual fit | Goal, schedule, equipment, recovery, pain context, nutrition readiness, budget, culture, and preferences |
| Delivery | Practical experience | Public site, intake, client portal, workout logger, nutrition, progress, and coach portal |

The brand is not a separate logo pasted onto a generic product. The typography, spacing, language, and coaching structure must express the same system.

---

## 6. Wordmark and Brand Presentation

### 6.1 Primary wordmark

`ASCEND`

The wordmark is typographic, monumental, editorial, and self-contained.

### 6.2 Hero treatment

Use Cormorant Garamond for the monumental hero wordmark.

```css
.hero__title {
  font-family: var(--font-display);
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: -0.07em;
  line-height: 0.78;
}
```

### 6.3 Navigation and compact treatment

Use Cinzel for the compact navigation wordmark and ceremonial brand labels.

```css
.wordmark {
  font-family: var(--font-ceremonial);
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.15em;
  white-space: nowrap;
}
```

### 6.4 Preferred hero hierarchy

1. **ASCEND**
2. *The Path to Divinity*
3. **Tame the flesh. Forge the form. Ascend.**
4. *A structured guide to an aesthetic, powerful physique.*
5. **by Sahmi El**

The main wordmark remains the dominant visual object. Supporting lines may move within the composition to preserve the existing site layout, but their hierarchy must remain clear.

### 6.5 Usage rules

- Keep the navigation wordmark horizontal.
- On phones, keep **ASCEND** on one line unless the viewport makes this impossible.
- Preserve clear space at least equal to the cap height of the letter `A`.
- Do not outline, bevel, emboss, glow, or apply metallic gradients.
- Do not stretch or condense the lettering.
- Do not insert an icon inside the wordmark.
- A supporting monogram may exist as a favicon or app mark but must not outrank the wordmark.
- Do not place the wordmark over visually noisy imagery without a strong contrast layer.

---

## 7. Colour System

Version 2.0 uses the palette implemented by the current site. These values supersede the earlier v1.0 approximations.

### 7.1 Core palette

| Token | Value | Role |
|---|---:|---|
| `asc-ink` | `#090907` | Primary dark background |
| `asc-ink-soft` | `#11100D` | Secondary dark background and dark button text |
| `asc-charcoal` | `#1A1814` | Elevated dark surface |
| `asc-ivory` | `#F3EDDF` | Primary light text on dark |
| `asc-ivory-2` | `#E8DFCD` | Quiet light rules and secondary light text |
| `asc-paper` | `#F7F3EA` | Forms, coach workspace, and light reading surfaces |
| `asc-gold` | `#C7A45B` | Primary accent |
| `asc-gold-bright` | `#DFBF77` | High-contrast gold on dark |
| `asc-gold-muted` | `#8C713E` | Large labels, ornaments, and restrained light-surface accents |
| `asc-muted-dark` | `#A7A093` | Secondary text on dark |
| `asc-muted-light` | `#706759` | Secondary text on paper |
| `asc-danger` | `#C87162` | Error and pain-warning state on dark |
| `asc-success` | `#92AD7A` | Completion and positive status on dark |

### 7.2 Semantic tokens

```css
:root {
  --asc-ink: #090907;
  --asc-ink-soft: #11100d;
  --asc-charcoal: #1a1814;
  --asc-ivory: #f3eddf;
  --asc-ivory-2: #e8dfcd;
  --asc-paper: #f7f3ea;
  --asc-gold: #c7a45b;
  --asc-gold-bright: #dfbf77;
  --asc-gold-muted: #8c713e;
  --asc-muted-dark: #a7a093;
  --asc-muted-light: #706759;
  --asc-danger: #c87162;
  --asc-success: #92ad7a;
  --asc-line: rgba(199, 164, 91, 0.34);
}
```

### 7.3 Contrast reference

| Pair | Approximate contrast | Use |
|---|---:|---|
| Ivory on ink | 17.07:1 | Body and display text on dark |
| Bright gold on ink | 11.25:1 | Small labels and controls on dark |
| Gold on ink | 8.44:1 | Accents and text on dark |
| Ink on paper | 18.00:1 | Body and controls on light |
| Muted-light on paper | 5.03:1 | Secondary body text on light |

### 7.4 Colour restrictions

- Gold is an accent, not a long-form body colour.
- Use bright gold for small text on dark backgrounds.
- Muted gold on paper is for large text, borders, or decoration; it is not suitable for small normal-weight text.
- Use `asc-muted-light`, not `asc-muted-dark`, for secondary text on paper.
- Do not use colour as the only status indicator.
- Avoid neon colours, rainbow gradients, chrome effects, and high-saturation dashboard palettes.
- Preserve the warm ivory environment rather than defaulting to cold pure white.

---

## 8. Typography

The ASCEND type system follows **Poetry + Proof + Ritual**.

- **Cormorant Garamond** carries emotion.
- **DM Sans** carries information.
- **Cinzel** carries ritual.

### 8.1 Font files and loading

Self-host the approved WOFF2 files in `public/fonts/`:

- `cormorant-garamond-latin.woff2`
- `cormorant-garamond-italic-latin.woff2`
- `dm-sans-latin.woff2`
- `cinzel-latin.woff2`

```css
@font-face {
  font-family: "Cormorant Garamond";
  src: url("/fonts/cormorant-garamond-latin.woff2") format("woff2");
  font-style: normal;
  font-weight: 400 700;
  font-display: swap;
}

@font-face {
  font-family: "Cormorant Garamond";
  src: url("/fonts/cormorant-garamond-italic-latin.woff2") format("woff2");
  font-style: italic;
  font-weight: 400 700;
  font-display: swap;
}

@font-face {
  font-family: "DM Sans";
  src: url("/fonts/dm-sans-latin.woff2") format("woff2");
  font-style: normal;
  font-weight: 400 700;
  font-display: swap;
}

@font-face {
  font-family: "Cinzel";
  src: url("/fonts/cinzel-latin.woff2") format("woff2");
  font-style: normal;
  font-weight: 400 600;
  font-display: swap;
}

:root {
  --font-display: "Cormorant Garamond", "EB Garamond", Georgia, serif;
  --font-sans: "DM Sans", Inter, Arial, sans-serif;
  --font-system: var(--font-sans);
  --font-ceremonial: "Cinzel", "Times New Roman", serif;
  --font-ritual: var(--font-ceremonial);
}
```

Load the font stylesheet before global component styles. Do not depend on `next/font`, a remote CDN, or an icon font in the Vite application.

### 8.2 Role assignments

| Typeface | Role | Use |
|---|---|---|
| Cormorant Garamond | Expressive display | Hero, major headings, programme titles, phase openers, quotations |
| DM Sans | Functional system | Body, navigation, buttons, forms, tables, targets, notes, helper text |
| Cinzel | Ceremonial accent | Compact wordmark, eyebrows, phase labels, seals, short manifesto cues |

### 8.3 Public-site type scale

| Style | Typeface | Weight | Size | Line height | Tracking |
|---|---|---:|---:|---:|---:|
| Hero wordmark | Cormorant | 500 | `clamp(65px, 16.2vw, 250px)` | 0.78–0.83 | `-0.07em` |
| Hero subtitle | Cormorant italic | 400 | `clamp(17px, 1.6vw, 24px)` | 1.15 | `0` |
| H1 | Cormorant | 500–600 | `clamp(48px, 7vw, 96px)` | 0.90–0.96 | `-0.04em` |
| H2 | Cormorant | 500–600 | `clamp(40px, 5vw, 72px)` | 0.95–1.02 | `-0.03em` |
| H3 | DM Sans | 600 | 24–32px | 1.15 | `-0.01em` |
| H4 | DM Sans | 600 | 18–22px | 1.25 | `0` |
| Eyebrow | Cinzel | 500–600 | 11–13px | 1.4 | `0.18em–0.24em` |
| Body | DM Sans | 400 | 16–18px | 1.55–1.75 | `0` |
| Small supporting copy | DM Sans | 400 | 14–15px | 1.5–1.6 | `0` |

### 8.4 Mobile readability standard

At viewport widths up to 760px:

- Public-site and assessment body copy: **16px minimum**.
- Form inputs, selects, and textareas: **16px minimum** to prevent iOS focus zoom.
- Meaningful portal supporting copy: **15px minimum**.
- Choice rows and consent text: **14px minimum**.
- Functional portal labels and compact status text: **11px minimum**.
- Public eyebrows, field labels, and action labels: **12px minimum**.
- Primary action controls: **12px minimum** with **48px minimum height**.
- Never shrink meaningful instructions to make a card fit. Reflow the layout first.

### 8.5 Typography rules

- Keep body copy to approximately 55–72 characters per line.
- Use sentence case or title case for display headings.
- Use uppercase only for short navigation, label, and ceremonial roles.
- Never use long uppercase paragraphs.
- Do not use Cinzel for body copy or form instructions.
- Avoid italic sans-serif for functional instructions.
- Use Cormorant italic only for short poetic support lines.
- Do not introduce additional font families.
- On phones, preserve legibility before compactness.

---

## 9. Spacing and Layout

### 9.1 Spacing scale

```css
:root {
  --asc-space-1: 0.25rem;  /* 4px */
  --asc-space-2: 0.5rem;   /* 8px */
  --asc-space-3: 0.75rem;  /* 12px */
  --asc-space-4: 1rem;     /* 16px */
  --asc-space-5: 1.5rem;   /* 24px */
  --asc-space-6: 2rem;     /* 32px */
  --asc-space-7: 3rem;     /* 48px */
  --asc-space-8: 4rem;     /* 64px */
  --asc-space-9: 6rem;     /* 96px */
  --asc-space-10: 8rem;    /* 128px */
}
```

### 9.2 Containers

```css
:root {
  --asc-reading: 44rem;
  --asc-content: 72rem;
  --asc-wide: 88.75rem; /* 1420px */
  --asc-gutter: clamp(1rem, 4vw, 3rem);
}
```

### 9.3 Grid

- Mobile: 4 columns
- Tablet: 8 columns
- Desktop: 12 columns
- Maximum primary shell: 1420px
- Primary editorial reading width: approximately 704px
- Standard desktop shell: `min(100% - 48px, 1420px)`
- Standard phone shell: `min(100% - 32px, 1420px)`

### 9.4 Composition rules

- Favour symmetry in the hero and ceremonial sections.
- Use asymmetry selectively in editorial content and proof sections.
- Use thin gold rules to create rhythm.
- Maintain generous negative space around display typography.
- Avoid more than one dominant visual idea in a viewport.
- Do not stack bordered cards merely to fill a grid.
- Keep the DOM order meaningful; use CSS grid placement only when visual order does not break reading order.

---

## 10. Shape, Borders, and Depth

ASCEND should feel architectural and editorial, not soft, playful, or app-generic.

```css
:root {
  --asc-border-hairline: 1px;
  --asc-rule: 1px solid rgba(199, 164, 91, 0.34);
  --asc-radius: 0;
  --asc-radius-functional: 2px;
  --asc-shadow-lift: 0 20px 60px rgba(9, 9, 7, 0.18);
}
```

- Use square corners by default.
- A 2px radius is permitted for fields and compact controls.
- Use borders and background contrast instead of heavy shadows.
- Avoid pill buttons except for compact status tags where the current interface already uses them.
- Avoid glassmorphism overload, neon glows, thick drop shadows, and floating-card excess.
- Reserve the optional lift shadow for modals or genuinely elevated panels.

---

## 11. Iconography and Ornament

### 11.1 Approved icon family

Use the exact 18-icon SVG family from the website. Do not substitute Lucide, Heroicons, Material Icons, Font Awesome, React Icons, emoji, or approximations on established surfaces.

| Area | Approved icon names |
|---|---|
| Client portal | `today`, `plan`, `nutrition`, `workout`, `progress` |
| Coach portal | `overview`, `athletes`, `applications`, `checkins`, `programmes`, `layers` |
| Utilities | `search`, `bell`, `plus`, `arrow`, `arrow-up-right`, `close`, `alert` |

### 11.2 SVG standard

```tsx
<svg
  viewBox="0 0 24 24"
  width="18"
  height="18"
  fill="none"
  stroke="currentColor"
  strokeWidth="1.7"
  strokeLinecap="round"
  strokeLinejoin="round"
  aria-hidden="true"
/>
```

The `today` icon is the approved filled exception. All others are thin-line icons.

### 11.3 Rules

- Default size: 18px.
- Default stroke width: 1.7px.
- Keep visible text labels beside navigation icons, including mobile bottom-navigation labels.
- Decorative icons use `aria-hidden="true"`.
- If an icon is the only label, expose an accessible name with a specific `<title>` or `aria-label`.
- Use simple arrows, diamonds, thin rules, and phase numerals as restrained ornaments.
- Do not mix line weights, corner styles, or icon libraries.

---

## 12. Photography and Art Direction

### Direction

- Sculptural, disciplined, human, and intentional
- Dramatic but not aggressive
- Warm monochrome, charcoal, ivory, muted skin tones, and restrained gold light
- Strong anatomy, movement, texture, fabric, iron, stone, shadow, and architecture
- Honest training environments rather than staged influencer luxury

### Composition

- Use directional negative space for text.
- Prefer controlled lighting and deep contrast.
- Crop with purpose; avoid cutting at joints where possible.
- Maintain one visual subject per frame.
- Use subtle grain rather than heavy filters.

### Avoid

- Generic smiling stock-fitness photography
- Body shaming or punishment imagery
- Fake before-and-after claims
- Over-sexualised presentation
- Injury glorification
- Images that imply guaranteed outcomes
- Busy gym backgrounds behind long text

### Alt text

Describe the meaningful content or purpose.

Good: `Athlete performing a controlled Romanian deadlift with a neutral spine in a quiet gym.`

Avoid: `Image of a person working out.`

---

## 13. Motion

Motion expresses control and progression.

```css
:root {
  --asc-duration-fast: 140ms;
  --asc-duration-base: 220ms;
  --asc-duration-slow: 420ms;
  --asc-ease: cubic-bezier(0.22, 1, 0.36, 1);
}
```

### Approved motion

- Subtle opacity and vertical reveal
- Thin rule expansion
- Slow image-mask reveal
- Controlled hover shift of 2–4px
- Smooth section transitions
- Sequential reveal of Tame → Forge → Ascend

### Avoid

- Constant loops
- Large parallax movement
- Rapid zooms or glitch effects
- Bouncing buttons
- Motion that delays access to content

### Reduced motion

```css
@media (prefers-reduced-motion: reduce) {
  html { scroll-behavior: auto; }
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## 14. Core Components

### 14.1 Public navigation

- Left: **ASCEND** wordmark.
- Centre/right: Method, Phases, Coaching, About, or the current approved labels.
- Primary action: **Begin Your Assessment** or **Apply for Coaching** once the final CTA decision is made.
- Minimum click target: 44 × 44px.
- Preserve the compact single-line wordmark on phones.
- The mobile menu must trap focus and close with Escape.

### 14.2 Buttons

```css
.button-primary-dark {
  min-height: 48px;
  background: var(--asc-gold);
  color: var(--asc-ink-soft);
  border: 1px solid var(--asc-gold);
}

.button-primary-light {
  min-height: 48px;
  background: var(--asc-ink-soft);
  color: var(--asc-ivory);
  border: 1px solid var(--asc-ink-soft);
}

.button-secondary {
  min-height: 48px;
  background: transparent;
  color: currentColor;
  border: 1px solid currentColor;
}
```

- Typeface: DM Sans 600–700.
- Desktop size: 12–16px depending on hierarchy.
- Phone size: at least 12px.
- Standard height: 48–54px.
- Radius: 0–2px.
- Use specific verbs: **Begin Assessment**, **Explore the Method**, **View Plan**, **Log Workout**.
- Avoid multiple primary buttons in one section.

### 14.3 Text links

- Underline on hover and focus.
- Use a visible underline offset.
- Do not rely on colour alone.
- Use descriptive link text.

### 14.4 Cards

Cards are secondary architecture.

- Surface: ink-soft, charcoal, ivory, or paper depending on context.
- Border: 1px hairline.
- Radius: 0–2px.
- Padding: 24–40px on desktop; 20–28px on phones.
- Avoid deep shadows unless elevation has a functional meaning.

### 14.5 Tables

- Use tables only for comparable records.
- Left-align text and right-align numeric values.
- Use sentence-case headers.
- Prefer horizontal rules; avoid dense vertical grids.
- On phones, reflow into stacked rows or provide an obvious horizontal-scroll container.
- Use semantic `<th>` elements and `scope`.

### 14.6 Callouts and notices

Use callouts for principles, safety notices, progression rules, application requirements, and next actions.

- Thin gold left or full border.
- Short Cinzel label.
- DM Sans body.
- Essential information must never live only inside a tooltip.

### 14.7 Modals and drawers

- Use the lift shadow only when needed.
- Trap focus.
- Restore focus to the triggering control when closed.
- Support Escape.
- Keep the close icon labelled.
- Prevent background scroll without shifting the layout.

---

## 15. Client Intake and Assessment

The assessment is a primary product interaction. It must feel private, complete, clear, and respectful.

### 15.1 Content scope

The nine-stage intake covers:

1. Identity and contact details.
2. Body measurements and current context.
3. Goals and urgency.
4. Training history and schedule.
5. Equipment access and exercise environment.
6. Movement comfort, pain, and caution screening.
7. Nutrition habits, preferences, budget, and barriers.
8. Recovery, sleep, cardio, and tracking readiness.
9. Final declarations, consent, and submission.

Do not silently shorten the approved source document.

### 15.2 Responsive composition

Desktop at approximately 1000px and above:

- Use a two-column intake composition.
- The form card is the **left** column.
- The description/brand panel is the **right** column.
- The form receives the larger column share.
- Keep the description visible while the user completes the form.

Mobile and narrow tablet:

- Stack to one column.
- The form card appears **first**.
- The description panel appears beneath the form.
- Preserve the same DOM reading order.

### 15.3 Title hierarchy

- The single form-card title is **Coaching Intake Assessment**.
- Do not repeat this title outside the card.
- Do not use a struck-through, decorative, or duplicate title.
- Each stage uses a concise title and one short orientation sentence.

### 15.4 Form controls

- Use visible labels; placeholders are examples, not labels.
- Explain why sensitive information is requested.
- Mark required and optional fields explicitly.
- Minimum control height: 48px; current standard is 52px.
- Phone control type: 16px minimum.
- Checkbox and radio target: 44 × 44px minimum.
- Allow multiple choice where the question supports multiple valid answers, including gym goals.
- Save progress when technically possible.
- Do not request the same information twice.

### 15.5 Errors and completion

- State what happened and how to fix it.
- Place field errors beside the field and provide a summary after failed submission.
- Move focus to the error summary.
- Preserve entered values after validation errors.
- On success, confirm the submission and explain the next coaching step.

### 15.6 Privacy and safety

Approved privacy direction:

> Your answers are used to shape your coaching plan and are treated as confidential coaching information.

The form must not imply diagnosis. Sharp, worsening, unstable, numb, tingling, or major-weakness symptoms require stopping heavy loading and seeking qualified assessment.

---

## 16. Homepage Architecture

### 16.1 Hero hierarchy

1. **ASCEND**
2. *The Path to Divinity*
3. **Tame the flesh. Forge the form. Ascend.**
4. *A structured guide to an aesthetic, powerful physique.*
5. **by Sahmi El**
6. One primary action and, where needed, one secondary action

### Hero rules

- Near-black background.
- Ivory hero wordmark.
- Restrained bright-gold details.
- Centred composition.
- Monumental Cormorant hero text.
- Large negative space.
- No more than two calls to action.
- The subtitle must not visually compete with ASCEND.
- Verify that **The Path to Divinity** wraps intentionally and never overflows.

### 16.2 The method

Present the three-part sequence:

- Tame the flesh
- Forge the form
- Ascend

Each part includes the mission, what changes, the client experience, and a short progression standard.

### 16.3 The coaching system

Explain the connected layers of brand, phase, training level, client profile, and delivery in clear visitor language.

### 16.4 Profile-first coaching

Show that plans are shaped by goal, experience, schedule, equipment, pain context, recovery, nutrition readiness, budget, culture, location, and preference.

### 16.5 What the client receives

Present the practical client experience:

- Programme overview
- Day-by-day training plan
- Nutrition and caloric targets
- Meal plan and food logging
- Workout logger with previous-set recall
- Progress and check-ins
- Coach feedback

### 16.6 Footer

Include:

- ASCEND wordmark
- The Path to Divinity
- ASCEND by Sahmi El
- Method / Coaching / Assessment / Privacy / Terms
- Contact or social links
- Copyright
- Health and coaching-scope disclaimer

---

## 17. Client Portal

### 17.1 Portal navigation

Primary client areas:

- Today / Dashboard
- My Plan
- Nutrition
- Workout Logger
- Progress

Desktop may use a sidebar. Mobile uses the established bottom navigation with all five icons and visible short labels.

### 17.2 Dashboard hierarchy

The first summary block combines two sides:

- **Streak/consistency side:** current streak, workouts this week, and adherence context.
- **Training side:** current phase, phase name, active programme, training days, and current programme week.

Do not repeat the streak or phase in a second lower summary card.

### 17.3 Overview cards

Use compact cards for:

- Active programme
- Completed workout logs
- Next scheduled check-in

Show session-level workout information: general workout name, expected duration, and exercise count. Do not turn the overview card into a list of every exercise.

### 17.4 Plan

The plan displays:

- Programme and phase context
- Training days
- Exercise name
- Sets
- Repetition range
- Rest
- Execution notes and substitutions

Do not display client-facing RIR unless the product owner explicitly reintroduces an advanced-client mode.

### 17.5 Nutrition

- Show calories remaining once.
- Place the protein, carbohydrate, and fat breakdown beside the calorie gauge on desktop and mobile.
- Stack only when the viewport genuinely requires it.
- Keep target, consumed, and remaining states clear.
- Keep meal plan and food logger inside the Health/Nutrition experience.

### 17.6 Progress

Show relevant trends and records:

- Bodyweight and assigned measurements
- Workout completion and adherence
- Nutrition adherence
- Strength progression by exercise
- Check-ins
- Coach feedback
- Phase and programme history

---

## 18. Workout Logger

The logger reduces manual entry and helps the client progress from prior performance.

### Required flow

1. Upload or select an assigned programme.
2. Parse programme days and exercises.
3. Select the programme day.
4. Automatically load that day's exercises.
5. Show the most recent recorded load and reps for each exercise.
6. Provide fields for the next working sets.
7. Save one atomic workout log.
8. Update history, streak, adherence, progress, and previous-set recall.

### Prescription standard

| Field | Rule |
|---|---|
| Exercise | Use a recognisable name. |
| Sets | Working sets only. |
| Reps | Use a clear target range. |
| Rest | Use an explicit practical duration. |
| Previous result | Show last load and reps where available. |
| Notes | Keep cues and substitutions short. |

### Client-facing exclusions

- No RIR labels or inputs in the current client experience.
- No manual recreation of an entire assigned programme exercise by exercise.
- No duplicate workout records created by a single submission.

---

## 19. Nutrition and Health Tools

### Nutrition targets

Present:

- Daily target
- Maintenance estimate
- Deficit direction
- Surplus direction
- Protein, carbohydrate, and fat targets
- Hydration
- Meal timing where assigned
- Supplement protocols where assigned
- Coach guidance

### Calculators

- BMI calculator supports metric and imperial units.
- Update the BMI value and class in real time.
- Show the healthy-weight reference range without presenting BMI as a diagnosis.
- BMR, TDEE, and calorie estimates must state their estimated nature.
- Avoid medical claims or false precision.

### Food logging

- Prioritise quick entry and clear serving units.
- Update the calorie gauge and macro progress from canonical entries.
- Do not store a second conflicting calorie-remaining value.
- Keep the meal plan, stock guidance, and food log connected to the assigned nutrition direction.

---

## 20. Demo Experience

The demo must show the product, not an empty shell.

### Required seeded state

The demo includes a complete representative client with:

- Profile and goal
- Phase II — Forging the Form
- Active programme and current week
- Four training days
- Current streak and adherence
- Completed workout history
- Nutrition targets and food entries
- One calorie gauge and macro progress
- Programme-day exercises
- Previous workout weights/reps
- Progress and check-in records
- Coach note and next check-in

### Isolation

- Demo records never write into live client records.
- Demo authentication and storage use a separate namespace or explicit demo discriminator.
- Seeding must occur before protected demo routes render.
- Resetting the demo must restore the original seed without affecting live data.

---

## 21. Coach Portal

### Primary areas

- Overview
- Athletes
- Applications
- Check-ins
- Programmes
- Workout logs
- Programme system

### Rules

- Coach access remains separate from client access even when the public login page visually prioritises one login space.
- Hidden coach access must remain discoverable only to authorised users; hiding a link is not security.
- The coach can review the full intake submission.
- Private coach notes must never become client-facing by default.
- Programme updates must remain connected to the client plan and logger.
- Use the approved thin-line icons and the lighter paper workspace without abandoning the brand typography and gold restraint.

---

## 22. Voice and Content

### 22.1 Voice qualities

| Quality | Use | Avoid |
|---|---|---|
| Direct | Clear actions and decisions | Long lectures before the action |
| Premium | Controlled language and confident restraint | Hype and forced luxury language |
| Mythic | Short ceremonial phrases | Constant dramatic language |
| Practical | Targets, steps, swaps, and next actions | Theory without application |
| Respectful | Neutral, capability-focused body language | Shame, humiliation, or punishment |
| Safety-aware | Visible stop and assessment rules | Pushing through worsening symptoms |

### 22.2 Approved phrase bank

#### Brand

- ASCEND
- The Path to Divinity
- Tame the flesh. Forge the form. Ascend.
- A structured guide to an aesthetic, powerful physique.
- by Sahmi El

#### Ceremonial

- Train with intention. Progress with structure.
- Tame what is disordered. Forge what is possible.
- Ascend through mastery.

#### Practical

- Add reps first. Add load when the range is complete.
- Repeat the load if form, pain, or recovery is not ready.
- Skip optional work when sleep, food, joints, or performance are off.
- The plan should fit the person, not force the person into a template.
- Track enough to make better decisions.

### 22.3 Language to avoid

- Retired GET DIVINE brand wording in current-facing content
- “Destroy yourself.”
- “Earn your food.”
- “Pain is weakness.”
- Guaranteed timelines or transformations
- False medical certainty
- Body-type labels presented as destiny
- Empty luxury terms without evidence
- Excessive exclamation marks

---

## 23. Responsive Behaviour

### Breakpoints

```css
/* Mobile first */
@media (min-width: 30rem) { /* 480px */ }
@media (min-width: 48rem) { /* 768px */ }
@media (min-width: 64rem) { /* 1024px */ }
@media (min-width: 90rem) { /* 1440px */ }
```

### Required test widths

- 320px
- 375px
- 390px
- 430px
- 768px
- 1024px
- 1440px

### Mobile rules

- Preserve the ASCEND hero hierarchy.
- Keep public and form body text at 16px minimum.
- Keep form controls at 16px minimum.
- Keep touch targets at least 44 × 44px; primary actions are at least 48px high.
- Stack the intake with the form first.
- Keep the description beneath the form.
- Keep all five client bottom-navigation items visible.
- Place macros beside the calorie gauge where they remain readable; otherwise stack as one intentional unit.
- Avoid horizontal page scrolling.
- Reflow tables and card grids rather than shrinking meaningful text.

### Desktop rules

- Allow the display type to become monumental.
- Increase breathing room rather than adding unnecessary columns.
- Keep reading text narrow.
- Keep the intake form on the left and description on the right.
- Keep the combined streak/phase block compact and balanced.

---

## 24. Accessibility and Dignity

Target **WCAG 2.2 AA**.

### Required

- Semantic heading hierarchy
- Keyboard access for every interactive element
- Visible focus states
- Skip-to-content link
- Sufficient contrast
- Form labels and instructions
- Accessible error summaries
- Descriptive links
- Alt text for meaningful images
- Captions or transcripts for meaningful video
- No colour-only meaning
- Reduced-motion support
- 44 × 44px minimum touch targets
- Logical DOM order
- Correct table headers
- Dialog focus management
- Announced status messages where required

### Safety and dignity

The ASCEND identity never overrides pain signals, medical boundaries, recovery needs, privacy, consent, or respectful client care.

---

## 25. Performance and Font Delivery

### Targets

- Use responsive AVIF/WebP imagery.
- Preload only the essential hero font files and imagery.
- Self-host the approved WOFF2 fonts.
- Use `font-display: swap`.
- Subset fonts only when licensing and language coverage remain appropriate.
- Avoid autoplay background video on phones.
- Lazy-load below-the-fold media.
- Reserve media dimensions to prevent layout shift.
- Keep JavaScript out of basic content interactions when HTML/CSS is enough.
- Treat Core Web Vitals as release criteria.

### Font verification

Before release, confirm in the browser's computed styles and network panel that:

- Cormorant Garamond loads for display text.
- DM Sans loads for body and controls.
- Cinzel loads for ceremonial labels.
- All font requests return successfully.
- The Vite build includes the WOFF2 assets.
- No Next.js font dependency remains.

---

## 26. SEO, Metadata, and App Identity

### Page-title pattern

`[Page purpose] | ASCEND`

Examples:

- `The Path to Divinity | ASCEND`
- `Coaching Intake Assessment | ASCEND`
- `Client Portal | ASCEND`

### Meta-description direction

- Direct and specific.
- Approximately 140–160 characters.
- No unsupported result promises.
- Use the new brand, subtitle, descriptor, and method consistently.

Example:

> Explore ASCEND — The Path to Divinity: structured physique coaching built around training, nutrition, recovery, progress, and individual fit.

### Required rebrand surfaces

Update:

- HTML title and meta description
- Open Graph title, description, and image alt text
- Social metadata
- Structured data/schema
- Favicon and app mark
- Web manifest name and short name
- Image alt text
- Email templates stored in the website project
- Reusable constants and configuration

Do not change URLs automatically.

---

## 27. Starter Design Tokens

```css
:root {
  /* Colour */
  --asc-ink: #090907;
  --asc-ink-soft: #11100d;
  --asc-charcoal: #1a1814;
  --asc-ivory: #f3eddf;
  --asc-ivory-2: #e8dfcd;
  --asc-paper: #f7f3ea;
  --asc-gold: #c7a45b;
  --asc-gold-bright: #dfbf77;
  --asc-gold-muted: #8c713e;
  --asc-muted-dark: #a7a093;
  --asc-muted-light: #706759;
  --asc-danger: #c87162;
  --asc-success: #92ad7a;
  --asc-line: rgba(199, 164, 91, 0.34);

  /* Typography */
  --asc-font-display: "Cormorant Garamond", "EB Garamond", Georgia, serif;
  --asc-font-body: "DM Sans", Inter, Arial, sans-serif;
  --asc-font-ritual: "Cinzel", "Times New Roman", serif;

  /* Space */
  --asc-space-1: 0.25rem;
  --asc-space-2: 0.5rem;
  --asc-space-3: 0.75rem;
  --asc-space-4: 1rem;
  --asc-space-5: 1.5rem;
  --asc-space-6: 2rem;
  --asc-space-7: 3rem;
  --asc-space-8: 4rem;
  --asc-space-9: 6rem;
  --asc-space-10: 8rem;

  /* Layout */
  --asc-reading: 44rem;
  --asc-content: 72rem;
  --asc-wide: 88.75rem;
  --asc-gutter: clamp(1rem, 4vw, 3rem);

  /* Shape and motion */
  --asc-radius: 0;
  --asc-radius-functional: 2px;
  --asc-rule: 1px solid rgba(199, 164, 91, 0.34);
  --asc-fast: 140ms;
  --asc-base: 220ms;
  --asc-slow: 420ms;
  --asc-ease: cubic-bezier(0.22, 1, 0.36, 1);
}
```

### Compatibility aliases

Existing `--gd-*` or unprefixed variables may remain temporarily inside the current code to avoid breaking the site. New work should use `--asc-*`. Compatibility aliases must not produce visible legacy brand copy.

---

## 28. Technical Implementation Standard

### Current stack

- React 19
- TypeScript 5.7 in strict mode
- Vite 6 with `@vitejs/plugin-react`
- React Router 7
- Tailwind CSS 4 plus custom CSS design tokens
- Custom LocalStorage/pub-sub stores
- Vercel deployment with SPA rewrite rules

### State boundaries

- Authentication store: role and session management.
- Application data store: athletes/leads, assignments, master plans, check-ins, food entries, and workout logs.
- Store canonical records; derive calories remaining, macro progress, BMI, streak, adherence, and counts.
- Keep demo state separate from live state.
- Do not copy server-only Next.js API or font code into the Vite application.

### Route expectations

The current route system includes public, application, client, demo, calculator, workout, progress, coach, and coach-portal experiences. Preserve existing URLs unless a separate migration is approved.

### Import order

```ts
import "./styles/ascend-fonts.css";
import "./styles/globals.css";
import "./styles/ascend-mobile-type.css";
```

Font declarations load first. Mobile type overrides load last.

---

## 29. Example Hero Markup

```html
<section class="hero" aria-labelledby="hero-title">
  <div class="hero__inner">
    <p class="hero__subtitle">The Path to Divinity</p>

    <h1 id="hero-title" class="hero__title">ASCEND</h1>

    <p class="hero__method">
      Tame the flesh. Forge the form. Ascend.
    </p>

    <p class="hero__descriptor">
      A structured guide to an aesthetic, powerful physique.
    </p>

    <div class="hero__actions">
      <a class="button-primary-dark" href="/apply">
        Begin Your Assessment
      </a>
      <a class="button-secondary" href="#method">
        Explore the Method
      </a>
    </div>

    <p class="hero__creator">by Sahmi El</p>
  </div>
</section>
```

---

## 30. Rebrand Search and Migration

Search the complete codebase, CMS exports, templates, and static assets for:

```text
GET DIVINE
Get Divine
GET DIVINE WITH SAHMI EL
Get Divine with Sahmi El
The Ascension Program
A structured path to an aesthetic, powerful physique.
```

### Search surfaces

- Navigation and mobile navigation
- Homepage and hero sections
- Buttons, footer, forms, popups, and modals
- Programme, pricing, FAQ, and onboarding pages
- Client and coach portals
- Legal/footer references
- Image alt text
- Page titles and metadata
- Open Graph/social metadata
- Structured data/schema
- Site manifest and app name
- Email templates
- Reusable components, constants, and configuration
- Demo seed data and LocalStorage defaults

### Allowed exceptions

- Historical/archive content explicitly identified as historical.
- Internal filenames or storage keys kept temporarily for non-breaking migration.
- Approved Phase III — Ascension and intentional Ascension programme-block names.

No internal exception may leak obsolete brand copy into the rendered current-facing experience.

---

## 31. Release QA

### Brand

- [ ] ASCEND is the dominant public wordmark.
- [ ] The Path to Divinity appears in the approved subtitle role.
- [ ] The descriptor uses **guide**, not **path**.
- [ ] The founder line reads **by Sahmi El** or the approved formal variant.
- [ ] Phase III — Ascension remains unchanged.
- [ ] Tame → Forge → Ascend remains unchanged.
- [ ] No obsolete current-facing brand references remain.

### Typography and icons

- [ ] All four WOFF2 files load successfully.
- [ ] Cormorant, DM Sans, and Cinzel appear in their assigned roles.
- [ ] Phone body and form text meet the minimum sizes.
- [ ] The exact 18-icon SVG family is used.
- [ ] No mixed icon libraries or emoji appear in established UI surfaces.

### Intake

- [ ] All nine stages and required questions are present.
- [ ] Form is left on desktop.
- [ ] Description is right on desktop.
- [ ] Form appears first on mobile.
- [ ] Coaching Intake Assessment is the only form-card title.
- [ ] Labels, controls, validation, consent, and submission work.

### Client and demo

- [ ] Dashboard combines streak and phase in the first summary block.
- [ ] Calories remaining appears once.
- [ ] Macros sit beside the calorie gauge.
- [ ] Plan, Nutrition, Workout Logger, Progress, and check-ins are populated in demo.
- [ ] Programme day loading and previous-set recall work.
- [ ] Client-facing RIR is absent.
- [ ] Demo and live data remain isolated.

### Responsive and interaction

- [ ] Tested at 320, 375, 390, 430, 768, 1024, and 1440px.
- [ ] The Path to Divinity does not overflow or wrap awkwardly.
- [ ] No page-level horizontal scrolling.
- [ ] Buttons, forms, navigation, and links work.
- [ ] Focus, keyboard, reduced-motion, and modal behaviour pass.

### Metadata and release

- [ ] Page titles, descriptions, Open Graph, schema, manifest, and favicon use ASCEND.
- [ ] Existing URLs are preserved.
- [ ] Production build passes.
- [ ] The deployed site is checked after publishing, not only the local build.

---

## 32. Decisions Still to Confirm

- [ ] Final homepage primary CTA: **Begin Your Assessment** or **Apply for Coaching**
- [ ] Final public navigation labels
- [ ] Whether coaching pricing is public or application-only
- [ ] Final photography library and licensing
- [ ] Final secondary seal/monogram policy
- [ ] Exact social-proof consent policy
- [ ] Final legal, privacy, cookie, and regional compliance copy
- [ ] Whether any advanced-client mode will reintroduce RIR
- [ ] Whether the existing domain/URLs will be renamed in a later migration

---

## 33. Source Basis and Version Notes

This guide is grounded in:

- Get Divine Website Style Guide v1.0 — the original digital design foundation.
- The approved ASCEND surgical rebrand — current name, subtitle, descriptor, founder line, and protected Ascension terminology.
- ASCEND's current published website implementation — current palette, typography, icon family, responsive behaviour, and portal composition.
- Get Divine Client Self-Assessment Form v2.0 — the complete intake scope, privacy, safety, and client-first information architecture.
- Get Divine Ascension Program Master Blueprint v2.0 — phase narrative, voice, profile-first coaching, and release standards.
- Premium DOCX Design Master Guide — hierarchy, scannability, spacing, accessibility, and QA standards.
- Athlete profile and nutrition documents — respectful coaching language, individual fit, food practicality, and traceable decisions.

### Version 2.0 changes

- Rebranded the system from GET DIVINE to ASCEND.
- Added The Path to Divinity, the updated descriptor, and by Sahmi El.
- Preserved Phase III — Ascension and the Tame → Forge → Ascend sequence.
- Replaced the v1.0 colour approximations with the current implemented palette.
- Added exact self-hosted font-loading requirements.
- Added the 18-icon SVG system.
- Added the larger mobile typography standard.
- Added the complete intake layout and title rules.
- Added the client portal, demo, nutrition, workout, and coach implementation standards.
- Added the codebase-wide rebrand search and release checklist.

