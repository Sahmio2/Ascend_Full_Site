# ASCEND / Get Divine Website Migration Handoff Standard

**Version:** 1.0  
**Baseline date:** 11 August 2026  
**Purpose:** Authoritative instructions for moving the newest ASCEND website build from its source environment into the user's own Antigravity codebase.  
**Target:** React 19 + TypeScript 5.7 + Vite 6 + React Router 7 + Tailwind CSS 4 + typed stores + Vercel SPA.  
**Status:** Binding project source for future migration and handoff work.

> **Instruction to every future AI agent:** Read this file completely before auditing, packaging, transposing, or merging ASCEND website code. Do not treat the hosted source framework as the target architecture. Preserve the newest interface and behaviour, then rewrite the framework-specific plumbing for the target stack.

---

## 0. The rule in one sentence

**Transpose the complete interface, behaviour, content and data contract; rewrite the framework-specific plumbing; preserve the target repository's architecture and stable data identifiers.**

The objective is not to copy a second application into the user's repository. The objective is a native migration into the existing React/Vite application.

---

## 1. When this source must be used

Use this standard whenever the user asks to:

- migrate or transpose the ASCEND/Get Divine website into their own codebase;
- make an Antigravity-compatible handoff ZIP;
- package the latest hosted build for another stack;
- merge newer ASCEND pages, forms, dashboards or effects into the target repository;
- update an earlier handoff so the latest build wins;
- explain how source code from the hosted site should fit the user's stack.

This standard governs the **full site**, not only `/apply` or one component.

---

## 2. Authority and precedence

### 2.1 Global precedence

Apply the following order whenever instructions conflict:

1. The user's explicit request in the current conversation.
2. This migration standard and its target-stack contract.
3. The newest verified source build for current UI, behaviour, content and responsive decisions.
4. The newest ASCEND website style guide and current domain specifications.
5. Existing target-repository contracts that preserve routes, stores, data keys and deployment.
6. Older handoff ZIPs, screenshots, prompts, templates and legacy Get Divine material.

### 2.2 Two truths must coexist

- **The newest source build controls what the product should look like and do.**
- **The target repository controls how that product must be implemented.**

Therefore, a newer source feature wins over an older UI, but Next/Vinext/Cloudflare code never wins over the target React/Vite architecture.

### 2.3 Recency rule

At the beginning of every future migration:

1. Record the source build date, commit or package version.
2. Record the target repository's current commit and package versions.
3. Identify any handoff packages already present.
4. Produce a short conflict matrix before changing code.
5. Use the newest source implementation for each affected feature.

Do not assume that the version numbers in this document remain current forever. They describe the verified 11 August 2026 baseline. A later checked-out source manifest replaces the baseline version numbers, while the architectural rules in this document remain binding unless the user changes them.

### 2.4 Legacy naming

Use current **ASCEND** public-facing copy. Legacy `Get Divine` names may remain in internal identifiers, TypeScript types or LocalStorage keys when changing them would break compatibility. Do not perform a global rename without a written migration plan and tests.

---

## 3. Baseline system profiles

## 3.1 Actual source stack used for the hosted ASCEND build

The hosted site built in ChatGPT Sites uses the following verified baseline:

| Layer | Source implementation as of 11 August 2026 |
|---|---|
| UI | React 19.2.6 |
| Language | TypeScript 5.9.3 |
| Application structure | Next.js 16.2.6 App Router conventions |
| Compatibility runtime | Vinext 0.0.50 |
| Build system | Vite 8.0.13 |
| Rendering | React Server Components plus client components |
| Styling | Tailwind CSS 4.2.1 plus custom `globals.css` tokens |
| Fonts | `next/font` with Cinzel, Cormorant Garamond and DM Sans |
| Database | Cloudflare D1, SQLite-compatible |
| ORM | Drizzle ORM 0.45.2 |
| Server endpoints | Next-style `app/api/**/route.ts` handlers |
| File storage | Cloudflare R2 |
| Runtime/deployment | Cloudflare Worker through ChatGPT Sites |
| Authentication | Sites-provided authentication headers and protected routes |
| Draft persistence | LocalStorage for a non-sensitive whitelist only |
| Motion/effects | CSS motion plus OGL/WebGL for `SpecularButton` |
| Programme parsing | `fflate` for DOCX-based workout programme uploads |

This is a **Next-style Sites/Vinext application on Cloudflare**, not a standard Next.js-on-Vercel project and not the user's Antigravity codebase.

## 3.2 Binding target stack

The user's own codebase uses:

| Layer | Required target contract |
|---|---|
| Framework | React 19 (`^19.0.0`) single-page application |
| Language | TypeScript 5.7 (`^5.7.0`) with strict typing |
| Build | Vite 6 (`^6.1.0`) with `@vitejs/plugin-react` |
| Routing | React Router v7 / `react-router-dom` (`^7.1.5`) in `App.tsx` |
| Styling | Tailwind CSS v4 plus vanilla CSS custom properties in `globals.css` |
| Design authority | Current `GET_DIVINE_STYLE_GUIDE.md` or its newest ASCEND successor |
| Authentication state | Typed `authStore.ts` with role/session handling |
| Product data | Typed `dataStore.ts` with CRUD operations and pub/sub updates |
| Current persistence | LocalStorage-backed adapters for demo/development data |
| Authentication key | `gd_auth_session_v1` |
| Application-data key | `gd_app_data_v1` |
| Hosting | Vercel SPA |
| Route reloads | `vercel.json` catch-all rewrite to the SPA entry point |
| Package manager | Preserve the target repository's npm lockfile and dependency policy |

Do not replace this stack with the source stack. Do not create a second app inside the repository.

## 3.3 Product shape

ASCEND remains one connected platform with two visual personalities:

- **Before login:** an editorial public website for discovery, programme information and coaching applications.
- **After login:** an app-like, mobile-first client portal and a desktop-friendly coach portal.

A PWA may be added incrementally. Do not split the product into separate native iOS/Android applications unless the user explicitly requests that expansion.

---

## 4. Full-site scope that must be preserved

### 4.1 Routes

At minimum, preserve and integrate the current equivalents of:

- `/`
- `/apply`
- `/client`
- `/coach`
- `/coach-portal`
- the current login and demo-entry routes;
- separate calculator, workout, progress and other portal routes already registered in the target `App.tsx`.

The receiving agent must generate a route inventory from both source and target code. Existing target URLs and aliases must continue working. Do not invent, delete or rename routes merely to make the migration easier.

### 4.2 Public website

Preserve:

- the ASCEND editorial identity and current public copy;
- the homepage sections and programme presentation;
- all current navigation and application entry points;
- responsive layouts and current imagery/assets;
- semantic headings, metadata and accessible links;
- the black, ivory and gold visual system.

### 4.3 Coaching application

Preserve the complete nine-stage assessment, including:

- every existing field key and payload path;
- validation and conditional reveal rules;
- progress, Back/Next behaviour and answer preservation;
- idempotent submission semantics;
- the submitted-application-to-coach-lead workflow;
- the latest contact-method and guardian-review fields in the current model;
- the source's current minor/guardian state values without silently renaming them.

Verified recent additions include `preferredContactMethod`, `assessment.identity.preferredContactMethod`, and `assessment.meta.guardianReviewRequired`. The current implementation allows applicants from age 13 and flags minors for guardian involvement and coach review. If a later source build changes the exact enum or threshold, preserve the later tested source behaviour and document the change.

Do not add a photo-upload requirement. It was not authorised.

### 4.4 Client portal

Preserve the current client experience, including:

- a compact overview with consistency/streak and current training phase together;
- active programme, completed-workout count and next check-in information;
- day-by-day workout programming with sets, reps and execution notes;
- **no client-facing RIR** unless the user explicitly restores it;
- calorie and macro targets with macros beside the gauge;
- “calories left” shown only once;
- hydration, meal timings, supplement protocols and coach guidance;
- BMI calculator with metric/imperial support, real-time category and healthy range;
- food logger and meal-plan areas under Health Calculators;
- a separate workout logger that can parse an uploaded programme, select a programme day, populate that day's workout and show the last lifted weight before the next set is recorded;
- check-ins and progress tracking;
- mobile typography large enough to read comfortably.

Workout summary blocks should show the general workout name, time and count rather than expanding every exercise in the overview.

### 4.5 Coach and demo experience

Preserve:

- separate coach/client authorisation even if the visible login entry is unified;
- coach lead/application review;
- athlete, assignment, plan, check-in and log management already supported by the target store contract;
- demo credentials/entry points required to inspect the client experience;
- strict separation between demo data and live data.

Do not ship placeholder pages for an existing feature.

---

## 5. Latest visual and interaction decisions

### 5.1 Core palette and type

Use the current source tokens as the baseline and reconcile them with the newest target style guide:

- near-black: `#090907`;
- ivory: `#F3EDDF`;
- gold: `#C7A45B`;
- brighter gold: `#DFBF77`;
- display typography: Cinzel and Cormorant Garamond;
- interface typography: DM Sans.

Transfer actual font files or use the target's approved font-loading method. Do not import `next/font` into Vite.

### 5.2 Compact form-field system

The newest application UI intentionally avoids a page full of oversized empty rectangles. Preserve these decisions:

- standard short answers use quiet underlined controls at approximately 42px high;
- input text remains 16px to avoid mobile zoom and preserve readability;
- textareas begin around 68px high and grow only where writing space is useful;
- age and other short values are content-sized;
- country/city and height/weight are paired when space permits;
- unit suffixes are part of the accessible control;
- short answer choices use compact segmented groups;
- selection targets remain at least 44px where appropriate;
- paired fields stack on very narrow screens;
- selected, focus, disabled and error states remain unambiguous;
- there is no horizontal overflow at supported mobile widths.

Do not “make it compact” by shrinking text below accessible sizes.

### 5.3 Gold specular CTA treatment

Preserve the OGL-powered `SpecularButton` treatment using the existing ASCEND palette:

- the application-start CTA (recently labelled `Begin Your Ascension Journey`) uses a slow continuous gold sweep so the effect is also visible on touch devices;
- `Apply for Coaching` uses a quieter pointer-proximity/follow effect;
- use gold line colours rather than a generic white highlight;
- preserve the button's route, native type, click semantics, size and copy;
- provide reduced-motion and non-WebGL/static fallbacks;
- prevent the canvas from intercepting pointer or keyboard input.

If later source copy changes, preserve the newer copy and apply the effect to the same actions.

### 5.4 Accessibility and responsiveness

Preserve:

- semantic labels and field descriptions;
- visible keyboard focus;
- validation that moves focus to the first invalid answer;
- sufficient contrast and touch targets;
- reduced-motion support;
- no horizontal overflow;
- mobile-first layouts at 320, 375, 390 and 430px;
- tablet/desktop checks at 768, 1024 and 1440px.

---

## 6. What transfers, what adapts, what is rewritten

### 6.1 Transfer with minor changes

The following are usually portable:

- design tokens and brand colours;
- responsive CSS and Tailwind class intent;
- public images, SVGs and approved font files;
- copy, form questions and option labels;
- TypeScript domain models that do not import framework APIs;
- validation rules;
- accessibility behaviour;
- client React components;
- OGL shader/component logic;
- payload field names and stable IDs.

### 6.2 Adapt to the target framework

| Source pattern | Target pattern |
|---|---|
| `app/**/page.tsx` | route page under `src/pages/` or `src/features/**/pages/` |
| `app/layout.tsx` | `App.tsx` plus target layout components |
| `next/link` | React Router `Link`/`NavLink` |
| `next/navigation` | React Router navigation hooks |
| `next/font` | CSS `@font-face`, local assets or the target font loader |
| Next metadata | target head/SEO mechanism |
| Server Component data read | hook/service call through typed store/repository |
| `fetch('/api/...')` | target service/repository method |
| source CSS entry | merge tokens deliberately into target `globals.css` |

### 6.3 Rewrite completely

These are source-runtime plumbing and must not enter the browser-ready merge layer:

- `app/api/**/route.ts` handlers;
- Server Actions and server-only modules;
- `headers()`, `cookies()` or `redirect()` from Next;
- ChatGPT Sites authentication headers;
- Vinext and Cloudflare Vite configuration;
- Cloudflare Worker entry points;
- D1 bindings and Drizzle runtime initialization;
- R2 bindings;
- Node-only filesystem, process or crypto APIs not supported by the browser.

Translate their behaviour into typed target interfaces. Do not comment them out and leave dead incompatible code behind.

---

## 7. Required target architecture

The receiving agent should fit the migration into the target repository's established naming. A preferred structure is:

```text
src/
├── App.tsx
├── main.tsx
├── pages/
├── layouts/
├── components/
├── features/
│   ├── applications/
│   │   ├── pages/
│   │   ├── components/
│   │   ├── application.types.ts
│   │   ├── application.validation.ts
│   │   └── application.service.ts
│   ├── client/
│   ├── coach/
│   ├── workouts/
│   ├── nutrition/
│   └── calculators/
├── services/
│   ├── authStore.ts
│   └── dataStore.ts
├── repositories/
│   ├── ApplicationRepository.ts
│   ├── DraftRepository.ts
│   └── LocalStorageDraftRepository.ts
├── storage/
│   ├── storageKeys.ts
│   └── migrations.ts
├── styles/
│   ├── globals.css
│   └── fonts.css
└── types/
```

This is a logical separation, not permission to duplicate existing target files. Reuse the target's current folders and imports where they already serve the same role.

### 7.1 Component boundary

UI components must call services or stores. They must not read or write LocalStorage, databases or remote APIs directly.

```text
UI component
    -> typed store/service
        -> repository interface
            -> LocalStorage/demo adapter now
            -> remote database/API adapter later
```

### 7.2 Store contract

- `authStore.ts` remains the role/session authority.
- `dataStore.ts` remains the application-level CRUD and pub/sub entry point.
- Store canonical records; derive dashboard percentages and summaries from those records.
- Keep demo records isolated from future live records.
- Preserve `gd_auth_session_v1` and `gd_app_data_v1` unless a versioned migration is intentionally added.
- Make I/O operations Promise-based even when the current adapter is synchronous internally.

---

## 8. Database-deferred architecture and privacy boundary

The user intends to add a database later. The migration must be ready for that future without installing a database now.

### 8.1 Current rules

1. Do not add Supabase, Firebase, D1, PostgreSQL, Neon or another database unless the user separately authorises it.
2. Put persistence behind typed repository/service interfaces.
3. Use asynchronous methods.
4. Preserve stable IDs, timestamps, form keys, submission IDs and payload shapes.
5. Add `schemaVersion` to locally stored records and provide versioned migration functions.
6. Keep database-specific code outside forms, dashboards and page components.
7. Use LocalStorage only for demo/development data and a non-sensitive draft whitelist.
8. Never store health details, pain answers, contact details or consent responses in LocalStorage drafts.
9. Never present LocalStorage as a secure production backend.
10. Do not accept real sensitive coaching applications into LocalStorage as a substitute for the future backend.

### 8.2 Recommended interfaces

```ts
export interface ApplicationRepository {
  create(input: ApplicationInput): Promise<ApplicationRecord>;
  getById(id: string): Promise<ApplicationRecord | null>;
  list(): Promise<ApplicationRecord[]>;
  update(
    id: string,
    input: Partial<ApplicationRecord>
  ): Promise<ApplicationRecord>;
  remove(id: string): Promise<void>;
}

export interface DraftRepository {
  load(draftId: string): Promise<SafeApplicationDraft | null>;
  save(draft: SafeApplicationDraft): Promise<void>;
  remove(draftId: string): Promise<void>;
}
```

`SafeApplicationDraft` must be an explicit whitelist type, not `Partial<ApplicationInput>`.

### 8.3 Safe pre-database behaviour

- Use fictional seed data for demos.
- Keep genuine final submission behind an `ApplicationRepository` adapter boundary.
- If no secure backend is configured, the production UI must fail safely or clearly indicate that real submission is unavailable; it must not silently write sensitive data to the browser.
- Preserve source submission idempotency by carrying a client-generated submission ID or equivalent deduplication key into the future repository contract.

### 8.4 Future database swap

When a database is authorised later, add an implementation such as:

```text
ApiApplicationRepository.ts
SupabaseApplicationRepository.ts
PostgresApplicationRepository.ts
```

Then change repository initialization, environment configuration and migrations. The pages, form components, validation, route structure and dashboards should not need to be rewritten.

### 8.5 Production decisions that remain separate work

Do not invent answers for:

- production database/provider selection;
- authentication provider and role enforcement;
- file-storage provider;
- retention/deletion policy;
- privacy notice and exact legal consent basis;
- verifiable guardian-consent workflow;
- production access-control/audit requirements.

These require the user's explicit decision and, where appropriate, professional privacy/legal review.

---

## 9. Migration execution procedure

### Phase 1 - Inspect before editing

1. Read this standard completely.
2. Inspect the newest source `package.json`, route tree, styles, models, API contracts and assets.
3. Inspect the target `package.json`, lockfile, `App.tsx`, `main.tsx`, `globals.css`, `authStore.ts`, `dataStore.ts`, types, demo seed and `vercel.json`.
4. Check repository instructions such as `AGENTS.md`.
5. Record dirty worktree changes and preserve unrelated user work.
6. Build a route/feature/data dependency matrix.
7. Identify older handoff code that must not override the latest source.

### Phase 2 - Establish contracts

1. Freeze the source's current UI/behaviour as the reference.
2. Freeze target route names, store keys and public interfaces.
3. List dependencies that are genuinely missing.
4. Define adapters for every source API, auth or storage dependency.
5. Define the sensitive-data boundary before connecting the form.

### Phase 3 - Port foundations

1. Merge design tokens deliberately; do not replace the entire target stylesheet.
2. Copy approved assets and fonts with stable paths.
3. Port shared accessible primitives and layouts.
4. Port `SpecularButton` with `ogl` only if it is not already present.
5. Add reduced-motion and capability fallbacks.

### Phase 4 - Port complete features

Port feature slices in dependency order:

1. shared shell, header, navigation and footer;
2. public homepage and programme content;
3. application model, validation and nine-stage form;
4. application repository/service adapter;
5. authentication and demo entry;
6. client portal and calculators;
7. workout/food/check-in/progress features;
8. coach portal and lead review.

Do not stop after producing page shells. Do not leave existing functionality as `TODO` or placeholder content.

### Phase 5 - Route and state integration

1. Register pages in the existing `App.tsx` route model.
2. Preserve aliases and browser-history behaviour.
3. Route all state through existing stores/services.
4. Add storage migrations only when schema changes require them.
5. Confirm Vercel direct-route reloads.

### Phase 6 - Verify and report

1. Run the target repository's install, lint, test, typecheck and build commands.
2. Test every route and role.
3. Test form validation, conditional fields, Back/Next, persistence and submission adapter behaviour.
4. Test responsive widths and keyboard-only use.
5. Search for forbidden source-framework imports.
6. Compare key pages with the newest source build.
7. Report changed files, dependencies, intentional differences and remaining backend limitations.

---

## 10. Antigravity handoff bundle contract

When the user asks for a handoff ZIP, create this structure:

```text
Handoff_Package/
├── 00_ANTIGRAVITY_START_HERE.md
├── 01_TECH_STACK_CONTRACT.md
├── 02_SOURCE_PLACEMENT_MAP.md
├── 03_ROUTE_INTEGRATION_MAP.md
├── 04_DATA_CONTRACT.md
├── 05_VALIDATION_AND_QA.md
├── ANTIGRAVITY_EXECUTION_PROMPT.md
├── HANDOFF_MANIFEST.json
├── PACKAGE_ADDITIONS.json
├── antigravity-merge-source/
│   ├── public/
│   │   └── fonts/
│   ├── src/
│   │   ├── pages/
│   │   ├── layouts/
│   │   ├── components/
│   │   ├── features/
│   │   ├── services/
│   │   ├── repositories/
│   │   ├── storage/
│   │   ├── styles/
│   │   └── types/
│   └── vercel.json
└── source-reference-read-only/       # Optional; never merge directly
```

### 10.1 Bundle rules

- `antigravity-merge-source/` contains only browser-ready React/Vite code.
- The archive root must not look like a second Next/Vinext app.
- Source-runtime code may appear only in `source-reference-read-only/` and must be clearly marked non-mergeable.
- Include the complete current site, not only the last edited page.
- `PACKAGE_ADDITIONS.json` contains only minimal missing packages, for example `ogl`; do not replace the target package manifest.
- `HANDOFF_MANIFEST.json` records the source baseline, target contract, file list and SHA-256 checksums.
- The placement map is file-specific, not a vague folder summary.
- The execution guide states: **newer features in this handoff win where UI or behaviour conflicts**.
- Preserve the target lockfile, routes, store keys, Tailwind setup and Vercel configuration.
- Validate the transposed merge source against React 19, TypeScript 5.7 and Vite 6 before archiving.

### 10.2 Required filename

```text
[Project_Name]_Antigravity_Compatible_Full_Site_Handoff_[YYYY-MM-DD].zip
```

### 10.3 Placement map baseline

| Supplied source | Preferred target | Required action |
|---|---|---|
| `public/fonts/*` | `public/fonts/` | copy only missing/updated approved fonts |
| `src/components/*` | existing shared component area | reconcile imports and avoid duplicates |
| `src/features/*` | existing feature folders | connect to target services/stores |
| `src/styles/*` | current style entry points | merge tokens; do not overwrite blindly |
| route pages | target pages/features | register in existing `App.tsx` |
| repositories | target service/data layer | bind to current demo adapter; keep async seam |
| `vercel.json` | repository root | merge SPA rewrite without deleting unrelated rules |

---

## 11. Forbidden migration mistakes

Do not:

- paste Next/Vinext source at the target repository root;
- import `next/*` packages into the target;
- ship server components or server handlers in browser code;
- retain D1/R2/Worker bindings in the merge layer;
- replace `App.tsx`, stores, the lockfile or `globals.css` wholesale;
- create another Vite/Next app inside the project;
- globally rename legacy internal identifiers or LocalStorage keys;
- let old screenshots or documents override the newest working UI;
- restore oversized boxed form fields;
- shrink form text to create false compactness;
- remove reduced-motion, focus or error states;
- restore client-facing RIR without instruction;
- duplicate “calories left” in the nutrition display;
- mix demo and live data;
- store sensitive assessment drafts in LocalStorage;
- add a database before authorisation;
- add an unauthorised photo-upload requirement;
- redesign unrelated pages during a scoped merge;
- leave mobile tables or matrices wider than the viewport;
- claim full parity when pages or backend-dependent actions are placeholders.

---

## 12. Acceptance and release gate

A migration or handoff is complete only when all applicable checks pass.

### 12.1 Architecture

- [ ] React 19 + TypeScript 5.7 + Vite 6 build succeeds.
- [ ] React Router 7 owns client routing.
- [ ] No Next, Vinext, D1, R2, Worker or server-only imports exist in the merge layer.
- [ ] Existing `App.tsx`, stores, storage keys, Tailwind setup and Vercel deployment remain intact.
- [ ] No second application was created.

### 12.2 Completeness

- [ ] Every current public, application, client, coach, demo and portal route is accounted for.
- [ ] Existing features are implemented, not replaced with placeholders.
- [ ] Latest compact form and gold specular CTA decisions are present.
- [ ] Client-facing RIR remains removed.
- [ ] Food, workout, calculator, check-in and progress features are preserved.

### 12.3 Data and privacy

- [ ] Stable field keys, IDs, timestamps and payload paths are preserved.
- [ ] Stores/services expose asynchronous methods.
- [ ] Components do not call LocalStorage directly.
- [ ] `schemaVersion` and storage migrations are present where needed.
- [ ] Demo/live data are separate.
- [ ] Sensitive draft exclusions are tested.
- [ ] No real sensitive submission is silently persisted to LocalStorage.

### 12.4 Interaction and accessibility

- [ ] Keyboard navigation and visible focus work.
- [ ] Validation focuses the first invalid field.
- [ ] Conditional fields and Back/Next answer retention work.
- [ ] Selected/error/disabled states are clear.
- [ ] Reduced-motion and non-WebGL fallbacks work.
- [ ] No horizontal overflow appears at 320, 375, 390, 430, 768, 1024 or 1440px.
- [ ] Direct URL reloads work on Vercel.

### 12.5 Engineering QA

- [ ] Dependency installation uses the target lockfile policy.
- [ ] Lint passes.
- [ ] TypeScript checking passes.
- [ ] Automated tests pass.
- [ ] Production build passes.
- [ ] Route and role smoke tests pass.
- [ ] `git diff --check` passes.
- [ ] Handoff checksums and ZIP integrity pass when a bundle is requested.

If unrelated pre-existing failures remain, report them separately and prove the migrated scope passes targeted checks. Do not conceal them.

---

## 13. Supporting source files and their role

The following project files may accompany this standard. Use them for domain content, brand tone, programme logic or document design. They are **not target-runtime architecture authorities** and they do not override a newer verified website build.

| File | Intended role |
|---|---|
| `Sahmi Lyra🌙.docx` | prompt-optimisation and editing discipline reference |
| `ASCEND_Client_Self_Assessment_Form_v2_0_Gold_Border_Corrected.docx` | assessment questions, safety language and domain structure |
| `ASCEND_Editable_Landing_Page_Template.docx` | landing-page content/template reference |
| `01 ASCEND_Path_to_Divinity_Master_Blueprint_v2_0.docx` | primary ASCEND programme, brand and system blueprint |
| `ASCEND_Sahmi_El_Athlete_Profile_v2_2_Gold_Border.docx` | athlete-profile and coaching-decision reference |
| `03_ASCEND_Personalized_Nutrition_Meal_and_Stock_Template_v2_0.docx` | nutrition, meal-plan and stock-guide domain reference |
| `PREMIUM DOCX DESIGN MASTER GUIDE(2).docx` | document-design guidance only; not website UI authority |
| `structure-for-ASCEND.txt` | strategic product split: editorial public site plus app-like portals |

When a supporting file conflicts with the latest site source, preserve the latest source implementation and note the conflict.

---

## 14. Required handoff report

At the end of a migration, provide:

1. the source build/commit used;
2. the target build/commit used;
3. routes and features migrated;
4. files added and changed;
5. dependencies added and why;
6. store, schema or payload changes;
7. tests and viewports checked;
8. intentional differences from the source;
9. unresolved backend/privacy decisions;
10. the final ZIP or changed repository location requested by the user.

Lead with the outcome. Do not claim that a database, secure authentication or production file storage exists when it has only been represented by an interface.

---

## 15. Ready-to-use future instruction

Use this message when starting the next migration:

```markdown
Use `ASCEND_Website_Migration_Handoff_Standard_v1_0_2026-08-11` as the binding migration source.

Migrate the newest complete ASCEND website build into my existing Antigravity codebase. First inspect both codebases and report the source/target stack, route inventory, feature inventory and conflicts. Then transpose the newest UI, behaviour, content and data contracts into my existing React 19 + TypeScript 5.7 + Vite 6 + React Router 7 + Tailwind CSS 4 architecture.

Preserve `App.tsx`, `authStore.ts`, `dataStore.ts`, `gd_auth_session_v1`, `gd_app_data_v1`, the target lockfile, Tailwind setup and Vercel SPA routing. Do not include Next/Vinext/Cloudflare runtime code in the merge layer. Use asynchronous repository interfaces so I can add a database later, but do not install a database now. Keep sensitive assessment data out of LocalStorage drafts and do not treat LocalStorage as production storage.

The newest source build wins for UI and behaviour. Complete the full site, not only `/apply`. Run the full acceptance gate from the standard and report every changed file, dependency, test result and remaining backend limitation.
```

---

## 16. Final principle

The migration succeeds when the target project feels and behaves like the newest ASCEND build **without ceasing to be the user's React/Vite application**. Visual parity is not permission to import incompatible runtime code, and architectural cleanliness is not permission to omit features.

