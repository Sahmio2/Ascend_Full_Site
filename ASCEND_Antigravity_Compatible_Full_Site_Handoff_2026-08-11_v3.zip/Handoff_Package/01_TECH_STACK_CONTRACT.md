# Tech Stack Contract

## Source stack (reference only)

| Layer | Latest hosted source |
|---|---|
| UI | React 19.2.6 |
| Language | TypeScript 5.9.3 |
| App conventions | Next.js 16.2.6 App Router |
| Compatibility runtime | Vinext 0.0.50 |
| Build | Vite 8.0.13 |
| Styling | Tailwind CSS 4.2.1 + custom CSS |
| Persistence | Cloudflare D1 + Drizzle 0.45.2 |
| Files | Cloudflare R2 |
| Runtime | Cloudflare Worker / ChatGPT Sites |

## Required target boundary

| Layer | Binding target |
|---|---|
| Framework | React 19 SPA |
| Language | TypeScript 5.7 strict |
| Build | Vite 6 |
| Routing | React Router v7 in the existing `App.tsx` |
| Styling | Tailwind CSS v4 + target CSS custom properties |
| Auth | existing typed `authStore.ts` |
| Data | existing typed `dataStore.ts` with pub/sub |
| Current persistence | LocalStorage-backed demo/development adapters only |
| Future persistence | async repository/API implementation, provider not yet chosen |
| Hosting | Vercel SPA |

## Protected target assets

Do not replace wholesale:

- `src/App.tsx`
- `src/main.tsx`
- `authStore.ts`
- `dataStore.ts`
- `globals.css`
- `package.json` or the lockfile
- Tailwind configuration
- existing `vercel.json`
- `gd_auth_session_v1`
- `gd_app_data_v1`

## Forbidden merge-layer dependencies

No `next/*`, Vinext, React Server Components, server actions, Next route handlers, ChatGPT auth headers, Cloudflare bindings, D1, R2, Wrangler, Worker entry points, Node filesystem/process APIs, or server-only redirects are present or permitted in `antigravity-merge-source/`.

## Package addition

The only requested runtime additions are `ogl@^1.0.11` for the gold specular border effect and `fflate@^0.8.2` for browser-side DOCX workout-table parsing. Add only missing packages.
