# File-by-File Source Placement Map

Use the target’s equivalent folders when names differ. Do not duplicate an existing component/store; reconcile it.

| Supplied path under `antigravity-merge-source/` | Preferred target | Required adaptation |
|---|---|---|
| `public/fonts/cinzel-latin.woff2` | `public/fonts/` | copy if missing; preserve approved local-font policy |
| `public/fonts/cormorant-garamond-italic-latin.woff2` | `public/fonts/` | copy if missing |
| `public/fonts/cormorant-garamond-latin.woff2` | `public/fonts/` | copy if missing |
| `public/fonts/dm-sans-latin.woff2` | `public/fonts/` | copy if missing |
| `src/App.integration.example.tsx` | reference beside `src/App.tsx` | copy route elements into existing `App.tsx`; do not replace it |
| `src/features/ascend/AscendFullSiteRoutes.tsx` | existing ASCEND route feature | use only if target route ownership allows; never add a second router |
| `src/features/ascend/index.ts` | ASCEND feature barrel | reconcile exports |
| `src/features/ascend/coach/AscendCoachRoutes.tsx` | coach route feature | register `/coach` and `/coach-portal` in existing route tree |
| `src/features/ascend/coach/CoachDashboard.tsx` | coach workspace feature | connect all mutations/loads to the coach bridge |
| `src/features/ascend/coach/CoachPortalPage.tsx` | coach page folder | wrap with target coach guard/layout |
| `src/features/ascend/coach/coachPortalAdapter.ts` | target services/adapters | bind to `dataStore` now or secure API later |
| `src/features/ascend/coach/index.ts` | coach feature barrel | reconcile exports |
| `src/features/ascend/portal/GetDivinePortalRoutes.tsx` | client/demo route feature | preserve legacy internal name if target imports depend on it |
| `src/features/ascend/portal/components/PortalPage.tsx` | portal components | preserve store subscription boundary |
| `src/features/ascend/portal/components/PortalShell.tsx` | portal layout/components | merge with existing guarded portal shell |
| `src/features/ascend/portal/data/clientPortalAdapter.ts` | client data adapter/service | register target `dataStore`; keep demo/live isolation |
| `src/features/ascend/portal/data/demoSeed.ts` | target demo seed | keep fictional and separate from live data |
| `src/features/ascend/portal/data/liveBridge.template.ts` | reference near `dataStore.ts` | adapt names to existing store; do not use as a second store |
| `src/features/ascend/portal/data/programmeParser.ts` | workout/programme data feature | retain browser-safe DOCX parsing; connect parsed output to target store |
| `src/features/ascend/portal/data/types.ts` | shared client/domain types | merge structurally with canonical target types |
| `src/features/ascend/portal/data/useClientPortalData.ts` | client hooks | retain pub/sub snapshot semantics |
| `src/features/ascend/portal/index.ts` | portal feature barrel | reconcile exports |
| `src/features/ascend/portal/pages/CalculatorPage.tsx` | calculator page feature | preserve metric/imperial and route aliases |
| `src/features/ascend/portal/pages/DashboardPage.tsx` | client dashboard page | mount behind target client guard |
| `src/features/ascend/portal/pages/DemoLoginPage.tsx` | login/demo page | connect demo auth starter to `authStore.ts` |
| `src/features/ascend/portal/pages/NutritionPage.tsx` | nutrition/health feature | connect food mutations to target store |
| `src/features/ascend/portal/pages/PlanPage.tsx` | plan feature | preserve day-by-day plan and no client-facing RIR |
| `src/features/ascend/portal/pages/ProgressPage.tsx` | progress/check-in feature | connect check-in mutation to target store |
| `src/features/ascend/portal/pages/WorkoutLoggerPage.tsx` | workout feature | preserve programme-day and prior-set recall |
| `src/features/ascend/public-apply/AscendPublicRoutes.tsx` | public route feature | register `/` and `/apply` in existing router |
| `src/features/ascend/public-apply/apply/ApplicationForm.tsx` | application feature | keep nine stages; connect repositories before production use |
| `src/features/ascend/public-apply/apply/assessment-model.ts` | application domain model | preserve all keys, validation, payloads and safe-draft whitelist |
| `src/features/ascend/public-apply/apply/form-primitives.tsx` | form components | reconcile with existing primitives without losing compact states |
| `src/features/ascend/public-apply/components/AscendIcon.tsx` | shared icons | reuse if identical; do not replace target icon system blindly |
| `src/features/ascend/public-apply/components/SpecularButton.css` | component stylesheet | load with component and reduced-motion fallback |
| `src/features/ascend/public-apply/components/SpecularButton.tsx` | shared component | add `ogl` only when missing; preserve Link/button semantics |
| `src/features/ascend/public-apply/data/applicationAdapter.ts` | application service | connect to target `dataStore.createApplication()` or repository |
| `src/features/ascend/public-apply/data/draftAdapter.ts` | draft service | use explicit safe repository; never full form state |
| `src/features/ascend/public-apply/index.ts` | public/application barrel | reconcile exports |
| `src/features/ascend/public-apply/pages/ApplicationPage.tsx` | application page | preserve current layout/order/responsiveness |
| `src/features/ascend/public-apply/pages/HomePage.tsx` | homepage | preserve latest public sections and CTA effects |
| `src/repositories/ApplicationRepository.ts` | target repositories | merge with canonical async application interface |
| `src/repositories/DraftRepository.ts` | target repositories | preserve SafeDraft type boundary |
| `src/repositories/LocalStorageDraftRepository.ts` | target repositories/storage | development/demo draft implementation only |
| `src/storage/migrations.ts` | target storage migrations | integrate with current schema-version mechanism |
| `src/storage/storageKeys.ts` | target storage constants | preserve existing key values; avoid duplicates |
| `src/styles/ascend-fonts.css` | target font CSS | import once from target main/global entry |
| `src/styles/ascend-full-site.css` | temporary parity entry | review after Tailwind; later reconcile rather than competing globally |
| `src/styles/ascend-hosted-latest.css` | target global/style modules | merge current selectors/tokens deliberately; do not overwrite wholesale |
| `vercel.json` | repository root | merge catch-all rewrite with existing headers/functions/rewrites |

`README.md` files are instructions and do not belong in runtime imports.
