# ASCEND Antigravity Full-Site Handoff

**Package date:** 11 August 2026  
**Source commit:** `96241cea4aa2a6ab06e7fb9cd954d760164b4075`  
**Source state:** clean, latest verified ASCEND Sites build  
**Target:** the existing Antigravity React/Vite repository

## Controlling instruction

Read `source-reference-read-only/project-sources/09-ASCEND_Website_Migration_Handoff_Standard_v1_0_2026-08-11.md` completely before merging.

> Newer features in this handoff win where UI or behaviour conflicts. The target repository still controls architecture, route registration, store ownership, persistence keys, lockfile, Tailwind setup, and deployment.

Do not copy `source-reference-read-only/latest-hosted-build/` into the target. It is a Next/Vinext/Cloudflare reference, not merge code.

## Merge sequence

1. Inspect the target `package.json`, lockfile, `src/App.tsx`, `src/main.tsx`, `globals.css`, `authStore.ts`, `dataStore.ts`, demo seed, storage keys, `vercel.json`, repository instructions, and current dirty worktree.
2. Record the target commit and produce a conflict matrix against this source baseline.
3. Read `01_TECH_STACK_CONTRACT.md` through `05_VALIDATION_AND_QA.md`.
4. Add only missing packages from `PACKAGE_ADDITIONS.json`; preserve the target lockfile policy.
5. Merge fonts and tokens. Use `ascend-hosted-latest.css` as the current selector reference, but reconcile it with the target stylesheet instead of overwriting `globals.css` wholesale.
6. Port the shared ASCEND components and then register the supplied pages inside the existing React Router tree.
7. Connect the application, safe-draft, portal, demo-auth, and coach bridges to the target stores/repositories.
8. Preserve `gd_auth_session_v1` and `gd_app_data_v1`. Do not store a genuine coaching application in LocalStorage.
9. Merge the Vercel catch-all rewrite with any existing Vercel configuration.
10. Run the acceptance gate in `05_VALIDATION_AND_QA.md` and report intentional differences and unresolved backend work.

## Non-negotiable current product decisions

- ASCEND public identity: “The Path to Divinity,” “Tame the flesh. Forge the form. Ascend.” and “by Sahmi El.”
- Nine-stage coaching intake with the latest compact field system.
- Input and mobile form text stays at least 16px; compactness comes from control shape and spacing.
- Gold OGL specular treatment on the application-start and coaching CTAs, with reduced-motion and non-WebGL fallbacks.
- Client dashboard combines streak/consistency and training phase.
- One calorie gauge; macros beside it; “calories left” shown once.
- No client-facing RIR.
- Workout logger selects a programme day, populates its exercises, and shows previous-set load/reps.
- Demo data is populated and isolated.
- `/apply` submissions feed the coach application/lead workflow through one repository contract.

## Database status

No production database is added by this package. LocalStorage remains demo/development persistence only. The repository interfaces are asynchronous so a future API/database implementation can replace the adapters without rewriting the UI.

## Completion condition

The migration is complete only after the receiving repository builds and every current route, role, form flow, calculator, logger, portal, and direct URL reload has been tested. This ZIP is a merge handoff, not proof that the user’s unseen target repository has already been integrated.
