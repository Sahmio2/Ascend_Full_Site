import { AscendFullSiteRoutes } from "./features/ascend";

/** Copy the route elements into the target App.tsx; do not replace App.tsx. */
export function AscendRouteIntegrationExample() {
  return <AscendFullSiteRoutes />;
}
