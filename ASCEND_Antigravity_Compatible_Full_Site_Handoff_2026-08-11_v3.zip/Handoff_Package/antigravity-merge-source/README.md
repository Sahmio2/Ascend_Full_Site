# Browser-Ready Merge Source

This directory contains only React/Vite/browser code, approved fonts, styles, typed adapters and a Vercel SPA rewrite template.

Copy feature files into equivalent existing target folders and register their page elements in the existing router. `App.integration.example.tsx` is an example, not a replacement `App.tsx`.

Import Tailwind through the target’s existing CSS entry. During parity review, load `src/styles/ascend-full-site.css` after the target globals; then reconcile accepted selectors/tokens instead of keeping competing global resets.
