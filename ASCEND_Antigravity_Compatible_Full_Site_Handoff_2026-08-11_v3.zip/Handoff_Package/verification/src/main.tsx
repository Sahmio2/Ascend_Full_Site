import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import {
  AscendFullSiteRoutes,
  registerAscendApplicationSubmitter,
} from "../../antigravity-merge-source/src/features/ascend";
import "./verify.css";

registerAscendApplicationSubmitter(async () => ({
  reference: "verification-only",
}));

function VerificationApp() {
  return <AscendFullSiteRoutes />;
}

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Missing #root mount element.");

createRoot(rootElement).render(
  <StrictMode>
    <BrowserRouter>
      <VerificationApp />
    </BrowserRouter>
  </StrictMode>,
);
