# Data and Repository Contract

## Boundary

```text
React page/component
  -> typed store/service
    -> repository or bridge interface
      -> LocalStorage/session demo adapter now
      -> secure API/database adapter later
```

Components must not access LocalStorage, a database, or remote API directly.

## Supplied seams

| Seam | Purpose | Target connection |
|---|---|---|
| `ApplicationRepository` | final application submission | `dataStore.createApplication()` or future secure API |
| `DraftRepository` | explicit non-sensitive draft whitelist | current local draft adapter |
| `registerAscendApplicationRepository` | installs final-submission implementation | target application repository |
| `registerAscendDraftRepository` | replaces safe draft implementation | target draft repository |
| `registerGetDivineLiveBridge` | client canonical records and mutations | existing `dataStore.ts` |
| `registerGetDivineDemoAuthStarter` | starts isolated demo session | existing `authStore.ts` |
| `registerAscendCoachBridge` | people, leads, plans, logs and documents | existing/future coach store/API |

Legacy `GetDivine` names in internal bridge identifiers are preserved to reduce target breakage. Public-facing copy is ASCEND.

## Stable identifiers

- `gd_auth_session_v1`
- `gd_app_data_v1`
- `gd_demo_data_v2` for isolated demo state
- assessment `schemaVersion`
- client-generated idempotency/submission key
- existing assessment field names and nested payload paths

## Safe draft boundary

`SafeDraft` is an explicit whitelist. It excludes name, contact details, location, body measurements, pain/safety answers, allergies, pregnancy/menstrual context, consent confirmations, and other sensitive assessment data. Do not broaden it to `Partial<FormState>`.

## Final submission boundary

A genuine coaching application must not be silently written to LocalStorage. Until a secure backend is configured, final submission must either use the target’s authorised repository/API or fail safely with the user’s page answers retained in memory.

## Future database

Do not add a provider now. Later, implement the same Promise-based interfaces with an API, Supabase, Postgres, or another authorised provider and change repository initialisation. Do not rewrite forms or pages for the database swap.

Provider selection, secure authentication, uploads, retention/deletion policy, privacy notice, guardian-consent verification, audit/access rules, and data migration remain separate decisions.
