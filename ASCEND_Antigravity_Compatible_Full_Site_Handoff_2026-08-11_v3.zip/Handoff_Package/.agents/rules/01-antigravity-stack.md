# Always On: Target Stack

This repository remains a React 19 + TypeScript 5.7 + Vite 6 + React Router 7 + Tailwind CSS 4 SPA hosted on Vercel. Preserve the existing `App.tsx`, stores, lockfile, Tailwind entry, storage keys and deployment. Never import Next/Vinext/Cloudflare runtime code or create a second application.
