# Always On: Change and Validation

Preserve unrelated user work. Merge rather than overwrite protected target files. Complete existing features without placeholders. Before handoff, run lint, strict typecheck, tests, production build, route/role checks, responsive/accessibility checks, forbidden-import scans, checksums and archive-integrity validation.
