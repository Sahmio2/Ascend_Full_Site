# Always On: Data and Privacy

Use typed async services/repositories. Components never access persistence directly. LocalStorage is demo/development only; safe drafts use an explicit non-sensitive whitelist. Do not store genuine sensitive coaching applications locally and do not add a database provider without explicit authorisation.
