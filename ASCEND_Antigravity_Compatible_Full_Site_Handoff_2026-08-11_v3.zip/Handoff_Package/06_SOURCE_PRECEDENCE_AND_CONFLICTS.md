# Source Precedence and Resolved Conflicts

## Precedence

1. Current user instruction.
2. Uploaded Migration Handoff Standard.
3. Latest verified hosted source commit.
4. ASCEND Website Style Guide v2.0 and current domain specifications.
5. Existing target-repository contracts.
6. Older ZIPs, screenshots, prompts and legacy Get Divine material.

## Source review findings

| Source conflict | Resolution in this handoff |
|---|---|
| Supporting self-assessment says guardian consent is required under 18; the latest web model accepts ages 13–100 and sets `guardianReviewRequired` only for the current under-14 branch. | Preserve the exact current web field/state contract; do not silently broaden it or claim a legally complete guardian-consent workflow. |
| Master blueprint and athlete profile use RIR in programming logic. | RIR may remain an internal coach concept, but it is excluded from the current client UI. |
| Older portal/source identifiers use Get Divine. | Preserve compatibility identifiers/keys; current visible brand copy is ASCEND. |
| DOCX design guide describes premium Word layout. | It governs documents only, not website UI. |
| Landing-page DOCX is an editable content template. | Use for brand/content reference; current working web layout wins. |
| Source app uses D1, R2, Next handlers and Sites auth. | These remain read-only reference and are replaced by browser-safe repository/bridge contracts. |

The strategic `structure-for-ASCEND.txt` decision is preserved: one connected platform with an editorial public site before login and app-like client/coach portals after login.
