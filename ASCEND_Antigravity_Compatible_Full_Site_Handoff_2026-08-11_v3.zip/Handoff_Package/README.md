# ASCEND Full-Site Migration Bundle

Start with `00_ANTIGRAVITY_START_HERE.md`.

- `antigravity-merge-source/` is browser-ready React/Vite integration source.
- `source-reference-read-only/latest-hosted-build/` is the exact latest hosted implementation reference and must not be merged as runtime code.
- `source-reference-read-only/project-sources/` contains the uploaded authoritative migration standard and supporting ASCEND sources.
- `verification/` is the React 19 / TypeScript 5.7 / Vite 6 compatibility harness used before packaging. Dependencies and build output are intentionally excluded.
