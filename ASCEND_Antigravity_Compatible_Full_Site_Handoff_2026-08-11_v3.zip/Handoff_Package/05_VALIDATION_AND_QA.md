# Validation and QA

## Package verification completed

- Hosted source worktree clean at commit `96241cea4aa2a6ab06e7fb9cd954d760164b4075`.
- Hosted source ESLint passed.
- Hosted source production build and artifact validation passed.
- Hosted source automated tests passed: 2/2.
- Browser-ready merge source passed TypeScript 5.7.3 strict checking.
- Browser-ready merge source passed a Vite 6.1.0 production build with React 19.0.0 and React Router 7.1.5.
- Forbidden framework/API import scan passed for `antigravity-merge-source/src`.

## Receiving-repository release gate

Run the target’s normal install, lint, typecheck, test and production-build commands. Then verify:

### Architecture

- Existing router, stores, keys, lockfile, Tailwind and Vercel rules remain intact.
- No second application or nested router exists.
- No Next/Vinext/Cloudflare/server-only code entered browser source.
- Components use stores/repositories, not direct persistence.

### Routes and roles

- Every URL in `03_ROUTE_INTEGRATION_MAP.md` renders and direct reloads work.
- Client, coach and demo guards behave correctly.
- Demo reset does not affect live data.

### Application

- All nine stages, field keys, conditions and review summaries are present.
- Validation focuses the first invalid answer.
- Back/Next retains answers.
- Safe draft contains only whitelisted fields.
- Final submission uses the application repository and preserves idempotency.
- Age 13 (the current under-14 branch) triggers the exact `guardianReviewRequired` state; production consent handling remains unclaimed.

### Product behaviour

- Specular CTAs retain routes, click/native button behaviour, gold palette and fallbacks.
- Client summary combines streak and phase.
- Macros sit beside the single calorie gauge and “calories left” appears once.
- No client-facing RIR is rendered.
- Workout logger loads programme days/exercises and recalls previous sets.
- Nutrition, food logging, BMI, progress and check-ins are functional.
- Coach applications, athletes, programmes, documents and workout review use the bridge.

### Responsive and accessible checks

Test 320, 375, 390, 430, 768, 1024 and 1440px. Confirm no horizontal page overflow, 16px mobile form type, visible focus, clear selected/error/disabled states, useful labels, touch targets, reduced motion, and non-WebGL fallback.

## Honest limitation

This bundle compiles independently, but the final integration cannot be certified until Antigravity runs this gate inside the actual target repository. No production database, secure file storage, or production auth provider is claimed by this handoff.
